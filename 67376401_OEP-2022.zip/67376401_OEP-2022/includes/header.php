<!DOCTYPE html>
<html>
<head>
	<title>ONLINE EXAM PORTAL</title>
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="assets/font-awesome/css/font-awesome.min.css">
</head>
<body>

