<style type="text/css">
	/*body {
		font-family: arial;
	}
	nav {
		position: fixed;
		top: -18px;
		left: 0;
		width: 100%;
	}
	nav ul {
		background-color: #015c92;
	}
	nav ul li {
		list-style-type: none;
		display: inline-block;
		padding: 15px;
		border-bottom: 2px solid transparent;
	}
	nav ul li:hover {
		background-color: #6cb6f5;
		border-bottom: 2px solid #5aa2e0;
	}
	nav ul li a {
		text-decoration: none;
		color: #fff;
	}
	.container {
		margin-top: 50px;
	}
	.rows {
		display: inline-block;
		margin: 10px;
		vertical-align: top;
	}
	.tables {
		width: 600px;
		border-collapse: collapse;
		border-color: #ddd;
	}
	.tables tr td {
		padding: 5px 10px;
		border-color: #ddd;
		color: #444;
	}
	.tables tr:nth-child(even) {
		background-color: #f0f1f5;
	}
	.tables thead th {
		background-color: #015c92;
		color: #fff;
	}
	h4 {
		color: #015c92;
	}
	*/
	.nav-link, .navbar-brand {
		color: #ddd !important;
	}
	.nav-link:hover, .navbar-brand:hover {
		color: #fff !important;
	}
</style>

<div class="sidebar">
	
</div>

<nav class="navbar navbar-expand-lg navbar-light bg-info mb-4">
	<div class="container">
		<a href="<?php echo isset($_SESSION['lecture']['token']) ? '?action=home' : '?action=welcome'; ?>" class="navbar-brand">Online Exam Portal</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-targe="#nav">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="nav">
			<ul class="navbar-nav ml-auto">
				<?php if(isset($_SESSION['lecture']['token'])) { ?>
				<li class="nav-item">
					<a href="?action=home" class="nav-link"><i class="fa fa-home"></i> Home</a>
				</li>
				<li class="nav-item">
					<a href="?action=addnew_exam" class="nav-link"><i class="fa fa-plus"></i> Add Exam</a>
				</li>
				<li class="nav-item">
					<a href="?action=list_exams" class="nav-link"><i class="fa fa-laptop"></i> Exams</a>
				</li>
				<li class="nav-item">
					<a href="?action=show_reports" class="nav-link"><i class="fa fa-line-chart"></i> Reports</a>
				</li>
				<?php } else { ?>
				<li class="nav-item">
					<a href="?action=welcome&my_modules=view" class="nav-link"><i class="fa fa-book"></i> myModules</a>
				</li>
				<li class="nav-item">
					<a href="?action=welcome&my_exams=view" class="nav-link"><i class="fa fa-pencil"></i> myExams</a>
				</li>
				<?php } ?>
				<li class="nav-item">
					<a href="?action=logout" class="nav-link"><i class="fa fa-sign-out"></i> Logout</a>
				</li>
			</ul>
		</div>
	</div>
</nav>
