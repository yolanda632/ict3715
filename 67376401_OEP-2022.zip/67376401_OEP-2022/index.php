<?php
//load classes
require_once('load_classes.php');

//instantiate class objects
$lecture = new Lecture();
$module = new Module();
$student = new Student();
$exam = new Exams();
$report = new Reports();

if(isset($_REQUEST['action'])) {

	switch ($_REQUEST['action']) {

		case 'login':
			include('view/login.php');
		break;

		case 'student-login':
			$email = htmlentities(stripslashes(trim($_REQUEST['email'])));
			$password = htmlentities(stripslashes(trim($_REQUEST['password'])));
			if(empty($email) || empty($password)) {
				$error = "<div class='alert alert-danger'><i class='fa fa-warning'></i> Please type your email and surname.</div>";
				include('view/login.php');
				exit();
			}
			if($student->login($email, $password)) {
				open_page('?action=welcome');
			}
			else {
				$error = "<div class='alert alert-danger'><i class='fa fa-warning'></i> Invalid login credentials</div>";
				include('view/login.php');
			}
		break;

		case 'logout':
			if(isset($_SESSION['lecture'])) {
				$lecture->logout();
			}
			else {
				$student->logout();
			}
			include('view/login.php');
		break;

		case 'welcome':
			include('view/welcome.php');
		break;

		case 'admin-login':
			include('view/adminlogin.php');
		break;

		case 'lecture-login':
			$email = htmlentities(stripslashes(trim($_REQUEST['email'])));
			$password = htmlentities(stripslashes(trim($_REQUEST['password'])));
			if(empty($email) || empty($password)) {
				$error = "<div class='alert alert-danger'><i class='fa fa-warning'></i> Please type your email and password.</div>";
				include('view/adminlogin.php');
				exit();
			}
			if($lecture->login($email, $password)) {
				open_page('?action=home');
			}
			else {
				$error = "<div class='alert alert-danger'><i class='fa fa-warning'></i> Invalid login credentials</div>";
				include('view/adminlogin.php');
			}
		break;

		case 'home':
			include('view/admin_home.php');
		break;

		case 'show_students':
			include('view/show_students.php');
		break;

		case 'show_modules':
			include('view/show_modules.php');
		break;

		case 'show_enrollments':
			include('view/show_enrollments.php');
		break;

		case 'list_exams':
			include('view/show_exams.php');
		break;

		case 'addnew_exam':
			include('view/addnew_exam.php');
		break;

		case 'upload-exam':

			$data = array(
				'moduleCode' => $_REQUEST['moduleCode'],
				'examType' => $_REQUEST['examType'],
				'examDate' => $_REQUEST['examDate'],
				'examTimeStart' => $_REQUEST['examTimeStart'],
				'examTimeEnd' => $_REQUEST['examTimeEnd'],
				// 'exam_paper' => $_FILES['exam_paper']['name'],
			);

			//check if directory exist, create one if not exists
			if(!is_dir('exams')) {
				mkdir('exams');
				mkdir('exams/examinations');
				mkdir('exams/submissions');
			}
			//
			$filename = $_FILES['exam_paper']['name'];

			$path = "exams/examinations/"; //get directory path for upload
			//
			$datafile = explode('.', $filename);
			//
			$file_ext = $datafile[1];
			//
			$new_filename = $data['moduleCode'].'_'.$data['examDate'].'_exam.'.$file_ext;
			//combine direcotry path and image file name
			$uploadpath = $path.$new_filename;
			//
			$newValue = ['exam_paper' => $new_filename];
			//
			$data = array_merge($newValue, $data);
			//
			if($exam->addNewExam($data)) {
				echo "<script>alert('Examination was created.')</script>";
				if(move_uploaded_file($_FILES['exam_paper']['tmp_name'], $uploadpath)) { //upload file to directory
					echo "<script>alert('File: '".$new_filename."' was uploaded successful.')</script>";
				}
				else {
					echo "<script>alert('Problem: Could not move file to destination directory.')</script>";
				}
			}
			else {
				echo "<script>alert('Failed to create new exam.')</script>";
			}
			echo "<script>window.open('?action=addnew_exam','_self')</script>";
		break;

		case 'get_exam':
			include('view/exam_info.php');
		break;

		case 'update-exam':

			$data = array(
				'moduleCode' => $_REQUEST['moduleCode'],
				'examType' => $_REQUEST['examType'],
				'examDate' => $_REQUEST['examDate'],
				'examTimeStart' => $_REQUEST['examTimeStart'],
				'examTimeEnd' => $_REQUEST['examTimeEnd'],
				'examID' => $_REQUEST['exam_id'],
			);
			//
			$filename = $_FILES['exam_paper']['name'];

			$path = "exams/examinations/"; //get directory path for upload
			//
			$datafile = explode('.', $filename);
			//
			$file_ext = $datafile[1];
			//
			$new_filename = $data['moduleCode'].'_'.$data['examDate'].'_exam.'.$file_ext;
			//combine direcotry path and image file name
			$uploadpath = $path.$new_filename;
			//
			$newValue = ['exam_paper' => $new_filename];
			//
			$data = array_merge($newValue, $data);
			//
			if($exam->updatingExam($data)) {
				echo "<script>alert('Examination has been updated.')</script>";
				if(move_uploaded_file($_FILES['exam_paper']['tmp_name'], $uploadpath)) { //upload file to directory
					echo "<script>alert('File: '".$new_filename."' was uploaded successful.')</script>";
				}
				else {
					echo "<script>alert('Problem: Could not move file to destination directory.')</script>";
				}
			}
			else {
				echo "<script>alert('Failed to update exam information.')</script>";
			}
			echo "<script>window.open('?action=list_exams','_self')</script>";
		break;

		case 'student_declare':
			include('view/student_declaration.php');
		break;

		case 'begin_exam':
			include('view/exam_start.php');
			include('includes/footer.php');
		break;

		case 'download-exam':
			$filename = $_REQUEST['filename']; //get file name to be downloaded
			$path = "exams/examinations/".$filename;
			header('Content-Type: application/octet-stream; charset=utf-8');
			header('Content-Disposition: attachment; filename='.$filename); //push file as a download
			readfile($path); //stream file for download
			exit();
		break;

		case 'exam_submit':
			//
			$filename = $_FILES['exam_paper']['name'];

			$path = "exams/submissions/"; //get directory path for upload
			//
			$datafile = explode('.', $filename);
			//
			$file_ext = $datafile[1];
			//
			$new_filename = $_REQUEST['studentID'].'_'.$_REQUEST['module_code'].'_Exam_'.date('Y-m-d').".".$file_ext;
			//combine direcotry path and image file name
			$uploadpath = $path.$new_filename;

			$data = array(
				'studentID' => $_REQUEST['studentID'],
				'module_code' => $_REQUEST['module_code'],
				'examDate' => date('Y-m-d'),
				'declaration' => "Yes",
				'file_upload' => (!empty($_FILES['exam_paper']['name'])) ? $new_filename : "none",
			);
			//call method to save student submitted examination. 
			if($exam->studentExamSubmit($data)) {
				echo "<script>alert('Examination has been submitted')</script>";
				if(move_uploaded_file($_FILES['exam_paper']['tmp_name'], $uploadpath)) { //upload file to directory
					echo "<script>alert('File: '".$new_filename."' was uploaded successful.')</script>";
					//$info = $student->getStudentByID($data['studentID']); //get student email address
					//$exam->sendMail($info->student_email); //call method to send email message to student
				}
				else {
					echo "<script>alert('Problem: Could not move file to destination directory.')</script>";
				}
			}
			else {
				echo "<script>alert('Failed to submit student exam.')</script>";
			} 
			echo "<script>window.open('?action=exam_end','_self')</script>";
		break;

		case 'exam_end':
			include('view/exam_end.php');
		break;

		case 'show_reports':
			include('view/show_reports.php');
		break;

		case 'filter_student':
			$searchTerm = htmlentities(trim($_REQUEST['search_value']));
			$response = $student->searchStudent($searchTerm);
			echo json_encode($response);
		break;

		case 'filter_exams':
			$searchTerm = htmlentities(trim($_REQUEST['search_text']));
			$response = $exam->searchExams($searchTerm);
			echo json_encode($response);
		break;

		case 'filter_modules':
			$searchTerm = htmlentities(trim($_REQUEST['search_text']));
			$response = $module->searchModules($searchTerm);
			echo json_encode($response);
		break;
		
		default:
			include('view/error.php');
			break;
	}

}
else {
	include('view/login.php');
}


function open_page($url) {
	echo "<script>window.location.href = '".$url."'</script>";
}

?>