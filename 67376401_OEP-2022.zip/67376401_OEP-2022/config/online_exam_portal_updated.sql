-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 14, 2021 at 07:36 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_exam_portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `enrollments`
--

CREATE TABLE `enrollments` (
  `id` int(6) NOT NULL,
  `student_number` varchar(8) DEFAULT NULL,
  `module_code` varchar(7) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `enrollments`
--

INSERT INTO `enrollments` (`id`, `student_number`, `module_code`) VALUES
(5, '44974825', 'ICT3715'),
(6, '54811163', 'ICT3715'),
(17, '44974825', 'ICT3641'),
(19, '56605234', 'ICT3715'),
(20, '56605234', 'ICT3611'),
(30, '37027166', 'ICT3715'),
(31, '37027166', 'INF3708'),
(46, '55796257', 'ICT3722'),
(58, '57100012', 'ICT3612'),
(59, '57100012', 'ICT3642'),
(63, '44512406', 'ICT3641'),
(64, '44512406', 'ICT3642'),
(68, '59079541', 'ICT3715'),
(69, '59079541', 'ICT3612'),
(81, '54803977', 'ICT3715'),
(96, '51856867', 'ICT3715'),
(116, '60635495', 'ICT3611'),
(117, '60635495', 'ICT3715'),
(129, '56233590', 'ICT3715'),
(130, '56233590', 'ICT3611'),
(135, '42198674', 'ICT3715'),
(136, '42198674', 'ICT3621'),
(142, '56891326', 'ICT3641'),
(160, '51837862', 'ICT3715'),
(161, '51837862', 'ICT3715'),
(164, '62441302', 'ICT3715'),
(165, '62441302', 'ICT2613'),
(168, '40878430', 'ICT3715'),
(169, '40878430', 'ICT3642'),
(173, '40878430', 'ICT3642'),
(174, '40878430', 'ICT3642'),
(176, '53436164', 'ICT3715'),
(180, '45693315', 'ICT3715'),
(188, '50178695', 'ICT3642'),
(189, '50178695', 'ICT3612'),
(192, '50424653', 'ICT2613'),
(197, '47275154', 'ICT3715'),
(198, '59376430', 'ICT3715'),
(199, '59376430', 'INF3708'),
(203, '46397930', 'ICT3715'),
(208, '42363136', 'ICT3715'),
(209, '42363136', 'ICT3612'),
(213, '62993062', 'ICT1511'),
(217, '46240314', 'ICT3715'),
(222, '64360342', 'ICT3611'),
(226, '46466029', 'ICT3715'),
(227, '46466029', 'ICT3715'),
(237, '48208124', 'ICT3715'),
(242, '47275154', 'ICT3715'),
(249, '56693141', 'ICT3715'),
(251, '39396363', 'ICT3715'),
(256, '58160329', 'ICT3715'),
(260, '54709695', 'ICT2613'),
(267, '62732765', 'ICT2612'),
(273, '50319477', 'ICT3642'),
(280, '31281745', 'INF3708'),
(281, '31281745', 'ICT3722'),
(287, '51972964', 'ICT3715'),
(288, '51972964', 'ICT1511'),
(299, '43212166', 'ICT3715'),
(300, '43212166', 'ICT2612'),
(312, '54262909', 'ICT3715'),
(316, '54288266', 'ICT3611'),
(317, '54288266', 'ICT3642'),
(323, '46466029', 'ICT3611'),
(326, '64898741', 'ICT3642'),
(328, '63878741', 'ENN1504'),
(331, '47304413', 'ICT2611'),
(335, '61315575', 'ICT3715'),
(336, '61315575', 'ICT1511'),
(339, '53951514', 'ICT3715'),
(340, '53951514', 'ICT3715'),
(345, '51388944', 'ICT3641'),
(349, '48202177', 'ICT3715'),
(356, '45634521', 'ICT3715'),
(357, '45634521', 'ICT3715'),
(365, '59166525', 'BSM1501'),
(366, '59166525', 'ICT1532'),
(375, '53961439', 'ICT3715'),
(376, '53961439', 'ICT2611'),
(381, '59362111', 'ICT2613'),
(382, '59362111', 'ICT3611'),
(383, '46018689', 'INF3708'),
(384, '46018689', 'ICT3641'),
(387, '55527884', 'ICT3715'),
(388, '55527884', 'ICT3611'),
(393, '56643772', 'ICT3641'),
(397, '40544605', 'ICT3612'),
(399, '57739129', 'ICT3715'),
(403, '32899238', 'ICT3715'),
(409, '41624815', 'ICT3715'),
(413, '58156887', 'ICT3715'),
(418, '32693802', 'COS1501'),
(424, '46397930', 'ICT3715'),
(425, '46397930', 'ICT3611'),
(428, '63989948', 'ICT3715'),
(429, '63989948', 'ICT3715'),
(440, '44797729', 'ICT3715'),
(441, '44797729', 'ICT3631'),
(467, '54657628', 'ICT3715'),
(469, '35375132', 'ICT3715'),
(473, '49810529', 'ICT2613'),
(483, '51348020', 'ICT2611'),
(493, '51328240', 'ICT2621'),
(494, '51328240', 'ICT3641'),
(497, '63288761', 'ICT2622'),
(499, '51103397', 'ICT3715'),
(506, '60293888', 'ICT3715'),
(507, '60293888', 'ICT3612'),
(510, '61033979', 'ICT3715'),
(520, '22845933', 'ICT3611'),
(527, '54935369', 'ICT3621'),
(531, '48114049', 'ICT3715'),
(532, '31475167', 'ICT3611'),
(551, '55334792', 'ICT2611'),
(558, '51548283', 'ICT3715'),
(559, '53508459', 'ICT3715'),
(563, '54511909', 'ICT3641'),
(570, '40080269', 'ICT2612'),
(573, '41058968', 'ICT3715'),
(574, '41058968', 'ICT3611'),
(580, '63288761', 'ICT3715'),
(595, '60977345', 'ICT2641'),
(612, '57739129', 'ICT3612'),
(621, '56353073', 'ICT3612'),
(629, '36565571', 'ICT3621'),
(635, '34605363', 'ICT3715'),
(640, '48615544', 'ICT3715'),
(646, '34802193', 'ICT2612'),
(650, '36904988', 'ICT3715'),
(651, '36904988', 'ICT3715'),
(660, '53007328', 'ICT3715'),
(664, '55422349', 'ICT3715'),
(670, '57281025', 'ICT3715'),
(673, '42849225', 'ICT2631'),
(675, '42849225', 'ICT3715'),
(683, '56993048', 'ICT1511'),
(684, '56993048', 'ICT1512'),
(703, '54511909', 'FAC1501'),
(705, '54042070', 'ICT3642'),
(706, '59620684', 'ICT3715'),
(707, '59620684', 'ICT2631'),
(718, '56161204', 'ICT3612'),
(719, '50675044', 'ICT3715'),
(720, '50675044', 'ICT3611'),
(726, '65921097', 'ICT3715'),
(732, '60322551', 'ICT3715'),
(742, '49391933', 'ICT3715'),
(750, '46150587', 'ICT3715'),
(762, '37393901', 'ICT3715'),
(763, '37393901', 'ICT3642'),
(767, '51092387', 'ICT3612'),
(772, '62835599', 'ICT3715'),
(773, '62835599', 'ICT3611'),
(777, '39537862', 'ICT3715'),
(778, '39537862', 'ICT3715'),
(779, '39537862', 'ICT3641'),
(781, '39537862', 'ICT3715'),
(782, '39537862', 'ICT3715'),
(784, '53043537', 'ICT3612'),
(788, '55923542', 'ICT3715'),
(789, '55923542', 'ICT3621'),
(795, '61384380', 'ICT3631'),
(796, '45319855', 'ICT3611'),
(798, '45628961', 'ICT3641'),
(804, '51557355', 'INF3708'),
(805, '51557355', 'FAC1501'),
(817, '46418474', 'ICT3715'),
(818, '46418474', 'INF3708'),
(822, '59258497', 'ICT3611'),
(826, '54059682', 'ICT3642'),
(830, '37085603', 'ICT3612'),
(831, '37085603', 'ICT3612'),
(833, '64211592', 'ICT2632'),
(838, '36833118', 'ICT3715'),
(846, '46148302', 'ICT3715'),
(859, '64270718', 'ICT3715'),
(865, '57452210', 'ICT3612'),
(870, '32901046', 'ICT3642'),
(887, '56941773', 'ICT3715'),
(890, '43716032', 'ICT3715'),
(893, '64317765', 'ICT1513'),
(900, '56997914', 'ENN1504'),
(904, '59012552', 'ICT3715'),
(908, '55437451', 'ICT1521'),
(909, '55437451', 'ICT2632'),
(914, '47562781', 'INF3708'),
(915, '57139725', 'ICT3715'),
(916, '57139725', 'INF3708'),
(917, '50499955', 'ICT3715'),
(918, '50499955', 'ICT3621'),
(923, '47562781', 'ICT3715'),
(924, '47562781', 'ICT3715'),
(934, '49301500', 'ICT2632'),
(937, '62142941', 'ICT2622'),
(945, '45015945', 'ICT3715');

-- --------------------------------------------------------

--
-- Table structure for table `examinations`
--

CREATE TABLE `examinations` (
  `id` int(6) NOT NULL,
  `student_number` varchar(8) DEFAULT NULL,
  `module_code` varchar(7) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `completion_time` datetime DEFAULT NULL,
  `declaration` varchar(3) NOT NULL,
  `exam_type` text NOT NULL,
  `uploads` longtext NOT NULL,
  `exam_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `examinations`
--

INSERT INTO `examinations` (`id`, `student_number`, `module_code`, `start_time`, `completion_time`, `declaration`, `exam_type`, `uploads`, `exam_date`) VALUES
(5, '44974825', 'ICT3715', '2021-01-08 13:07:00', '2021-01-08 13:07:00', 'Yes', 'Document Upload', '', '2021-01-08'),
(6, '54811163', 'ICT3715', '2021-01-10 10:02:00', '2021-01-10 10:08:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT3715_ReadMeFirst_Hendrik%20Abraham%20Krug.pdf', '2021-01-10'),
(17, '44974825', 'ICT3641', '2021-01-08 13:07:00', '2021-01-10 21:27:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT3715_ReadMeFirst_Hendrik%20Abraham%20Krug.pdf', '2021-01-12'),
(19, '56605234', 'ICT3715', '2021-01-10 22:05:00', '2021-01-10 22:07:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT3715_ReadMeFirst_Hendrik%20Abraham%20Krug.pdf', '2021-01-12'),
(20, '56605234', 'ICT3611', '2021-01-10 22:07:00', '2021-01-10 22:11:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT3715_ReadMeFirst_Hendrik%20Abraham%20Krug.pdf', '2021-02-18'),
(30, '37027166', 'ICT3715', '2021-01-11 21:07:00', '2021-01-11 21:07:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT3715_ReadMeFirst_Hendrik%20Abraham%20Krug.pdf', '2021-01-11'),
(31, '37027166', 'INF3708', '2021-01-11 21:08:00', '2021-01-11 21:09:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT3715_ReadMeFirst_Hendrik%20Abraham%20Krug.pdf', '2021-01-11'),
(46, '55796257', 'ICT3722', '2021-01-13 21:25:00', '2021-01-13 21:30:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT3715_ReadMeFirst_Hendrik%20Abraham%20Krug.pdf', '2021-01-13'),
(58, '57100012', 'ICT3612', '2021-01-16 21:57:00', '2021-01-16 22:03:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT3715_ReadMeFirst_Hendrik%20Abraham%20Krug.pdf', '2021-01-16'),
(59, '57100012', 'ICT3642', '2021-01-16 22:03:00', '2021-01-16 22:04:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT3715_ReadMeFirst_Hendrik%20Abraham%20Krug.pdf', '2021-01-17'),
(63, '44512406', 'ICT3641', '2021-01-19 15:14:00', '2021-01-19 15:19:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT3715_ReadMeFirst_Hendrik%20Abraham%20Krug.pdf', '2021-01-20'),
(64, '44512406', 'ICT3642', '2021-01-19 15:19:00', '2021-01-19 15:26:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT3715_ReadMeFirst_Hendrik%20Abraham%20Krug.pdf', '2021-01-21'),
(68, '59079541', 'ICT3715', '2021-01-19 19:39:00', '2021-01-19 19:45:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT3715_ReadMeFirst_Hendrik%20Abraham%20Krug.pdf', '2021-01-19'),
(69, '59079541', 'ICT3612', '2021-01-19 19:45:00', '2021-01-19 19:54:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT3715_ReadMeFirst_Hendrik%20Abraham%20Krug.pdf', '2021-01-20'),
(81, '54803977', 'ICT3715', '2021-01-22 13:30:00', '2021-01-22 13:33:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT3715_ReadMeFirst_Hendrik%20Abraham%20Krug.pdf', '2021-02-03'),
(96, '51856867', 'ICT3715', '2021-01-25 06:45:00', '2021-01-25 17:03:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT3715_ReadMeFirst_Hendrik%20Abraham%20Krug.pdf', '2021-01-25'),
(116, '60635495', 'ICT3611', '2021-01-27 20:12:00', '2021-01-27 20:15:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT3715_ReadMeFirst_Hendrik%20Abraham%20Krug.pdf', '2021-01-27'),
(117, '60635495', 'ICT3715', '2021-01-27 20:15:00', '2021-01-27 20:17:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT3715_ReadMeFirst_Hendrik%20Abraham%20Krug.pdf', '2021-01-26'),
(129, '56233590', 'ICT3715', '2021-01-28 04:11:00', '2021-01-28 04:24:00', 'Yes', 'Document Upload', '', '2021-06-23'),
(130, '56233590', 'ICT3611', '2021-01-28 04:25:00', '2021-01-28 04:27:00', 'Yes', 'Document Upload', '', '2021-07-15'),
(135, '42198674', 'ICT3715', '2021-01-29 11:01:00', '2021-01-29 11:02:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Study%20Plan_ZAMA%20CYNTHIA%20NGCOBO.pdf', '2021-01-30'),
(136, '42198674', 'ICT3621', '2021-01-29 11:02:00', '2021-01-29 11:03:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT3715_Tut102_2021_ZAMA%20CYNTHIA%20NGCOBO.pdf', '2021-01-31'),
(142, '56891326', 'ICT3641', '2021-01-30 13:23:00', '2021-01-30 13:26:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/56891326_MAHESH%20AMRATLAL%20JINA.pdf', '2021-05-13'),
(160, '51837862', 'ICT3715', '2021-02-02 12:16:00', '2021-02-02 12:18:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Discussion%20on%20about%20the%20Digital%20Divide_DANGISA%20IGNITIOUS%20SH.pdf', '2021-02-02'),
(161, '51837862', 'ICT3715', '2021-02-02 12:19:00', '2021-02-02 12:20:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Exam%20Practice%20Questions%20-%20ALL%20Included%20Chapte_DANGISA%20IGNITIOUS%20SH.pdf', '2021-02-02'),
(164, '62441302', 'ICT3715', '2021-02-02 12:36:00', '2021-02-02 12:36:00', 'Yes', 'Document Upload', '', '2021-02-02'),
(165, '62441302', 'ICT2613', '2021-02-02 12:36:00', '2021-02-02 12:39:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/CATALOGUE_lethabo%20ngoakwana%20mo.pdf', '2021-02-02'),
(168, '40878430', 'ICT3715', '2021-02-02 16:25:00', '2021-02-02 16:33:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/1_R%20MOODLEY.pdf', '2021-11-17'),
(169, '40878430', 'ICT3642', '2021-02-02 16:33:00', '2021-02-02 16:34:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/2_R%20MOODLEY.pdf', '2021-08-13'),
(173, '40878430', 'ICT3642', '2021-02-02 16:40:00', '2021-02-02 16:46:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/2_R%20MOODLEY%201.pdf', '2021-02-11'),
(174, '40878430', 'ICT3642', '2021-02-02 16:47:00', '2021-02-02 16:47:00', 'No', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/2_R%20MOODLEY%202.pdf', '2021-02-01'),
(176, '53436164', 'ICT3715', '2021-02-02 18:49:00', '2021-02-02 18:58:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/_layouts/15/Doc.aspx?sourcedoc=%7B165B4E8B-7A0F-4D1C-AF84-810A45CB3ABA%7D&file=Case%2BStudy%2B_ICT3611%2B-%2Bsemester%2B2__KATLEGO%20HARRISON%20NAM.docx&action=default&mobileredirect=true', '2021-02-02'),
(180, '45693315', 'ICT3715', '2021-02-03 13:26:00', '2021-02-03 13:28:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/PHP_RHANDZU%20RIKHOTSO.pdf', '2021-02-03'),
(188, '50178695', 'ICT3642', '2021-02-05 17:19:00', '2021-02-05 17:22:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/4_5773752599329113636_P%20T%20MOGALE.jpg', '2021-02-10'),
(189, '50178695', 'ICT3612', '2021-02-05 17:22:00', '2021-02-05 17:34:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/plpp_answers_P%20T%20MOGALE.pdf', '2021-02-18'),
(192, '50424653', 'ICT2613', '2021-02-06 11:28:00', '2021-02-06 11:35:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT%203722%20Assignment%204_kenalemang%20rita%20kopa.pdf', '2021-02-06'),
(197, '47275154', 'ICT3715', '2021-02-06 21:08:00', '2021-02-06 21:10:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT3715_ASsignment_01_TestFormCreate_47275175_Phillip%20Odendaal.pdf', '2021-02-06'),
(198, '59376430', 'ICT3715', '2021-02-07 21:25:00', '2021-02-07 21:26:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Macintosh_Yannick%20Mfunyi%20Kanko.pdf', '2021-02-07'),
(199, '59376430', 'INF3708', '2021-02-07 21:27:00', '2021-02-07 21:28:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/SWOT%20Analysis%20of%20Samsung_Yannick%20Mfunyi%20Kanko.pdf', '2021-02-07'),
(203, '46397930', 'ICT3715', '2021-02-08 23:19:00', '2021-02-08 23:21:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Alphabets_CELIA%20SEGANELE%20PHALE.pdf', '2021-02-27'),
(208, '42363136', 'ICT3715', '2021-02-09 21:43:00', '2021-02-09 21:48:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/assgn%201_NHLANHLA%20LUCKY%20KGATL.pdf', '2021-03-01'),
(209, '42363136', 'ICT3612', '2021-02-09 21:49:00', '2021-02-09 21:50:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/assgn%201-1_NHLANHLA%20LUCKY%20KGATL.pdf', '2021-02-26'),
(213, '62993062', 'ICT1511', '2021-02-10 12:34:00', '2021-02-10 12:38:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/A%20guide%20to%20Assignment%201%20Calculations%202019%20(1)_Leonard%20lehlohonolo.pdf', '2021-02-10'),
(217, '46240314', 'ICT3715', '2021-02-11 01:14:00', '2021-02-11 01:18:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT3715_Tut102_2021_L%20MADIYA.pdf', '2021-02-11'),
(222, '64360342', 'ICT3611', '2021-02-11 12:15:00', '2021-02-11 12:17:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Welcome%20Scan_NONHLAKANIPHO%20HEPHOD.jpg', '2021-02-02'),
(226, '46466029', 'ICT3715', '2021-02-11 20:36:00', '2021-02-11 20:37:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/techmemes-20years_B%20J%20BROWN.jpg', '2021-10-04'),
(227, '46466029', 'ICT3715', '2021-02-11 20:37:00', '2021-02-11 20:39:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/external-content.duckduckgo.com_B%20J%20BROWN.jpg', '2021-10-04'),
(237, '48208124', 'ICT3715', '2021-02-13 10:21:00', '2021-02-13 10:36:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/_layouts/15/Doc.aspx?sourcedoc=%7B57C7821E-5B5F-4166-ACBA-0C89EA44CF01%7D&file=Random_R%20A%20KAYWA.docx&action=default&mobileredirect=true', '2021-02-13'),
(242, '47275154', 'ICT3715', '2021-02-14 10:01:00', '2021-02-14 10:03:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT3715_ASsignment_01_TestFormCreate_47275175_Phillip%20Odendaal%201.pdf', '2021-03-29'),
(249, '56693141', 'ICT3715', '2021-02-15 08:03:00', '2021-02-15 08:13:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/EHS%20Newsletter%20Midterm%20III,%202020_PORTIA%20NYATHI.pdf', '2021-02-15'),
(251, '39396363', 'ICT3715', '2021-02-15 14:08:00', '2021-02-15 14:13:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/001_2021_0_b_NISHANDHRAN%20GANAS%20PI.pdf', '2021-02-15'),
(256, '58160329', 'ICT3715', '2021-02-16 09:56:00', '2021-02-16 09:59:00', 'No', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT3715_Tut102_2021_Asanda%20Matini.pdf', '2021-02-26'),
(260, '54709695', 'ICT2613', '2021-02-16 12:46:00', '2021-02-16 12:47:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Switch%20case_T%20A%20LUNGA.pdf', '2021-02-25'),
(267, '62732765', 'ICT2612', '2021-02-17 14:52:00', '2021-02-17 14:57:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Assignment%202_ARDLIGHT%20GUTUKUNUHWA.pdf', '2021-02-03'),
(273, '50319477', 'ICT3642', '2021-02-17 22:05:00', '2021-02-17 22:07:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT3642_Introduction_D%20D%20MBEDLA.pdf', '2021-02-26'),
(280, '31281745', 'INF3708', '2021-02-18 09:17:00', '2021-02-18 09:20:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/001_2021_0_b_K%20PILLAY.pdf', '2021-05-21'),
(281, '31281745', 'ICT3722', '2021-02-18 09:23:00', '2021-02-18 09:25:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/101_2021_3_b_K%20PILLAY.pdf', '2021-06-24'),
(287, '51972964', 'ICT3715', '2021-02-18 16:46:00', '2021-02-18 16:52:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/51972964%20ict3715%20first%20task1%20aboutme_M%20A%20C%20PINTO.pdf', '2021-02-18'),
(288, '51972964', 'ICT1511', '2021-02-18 16:53:00', '2021-02-18 16:57:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/51972964%20ict3715%20first%20task1%20aboutme_M%20A%20C%20PINTO%201.pdf', '2021-02-17'),
(299, '43212166', 'ICT3715', '2021-02-20 13:37:00', '2021-02-20 13:42:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/4_6041740700125497416_DINAH%20MOKHOMO.pdf', '2021-02-22'),
(300, '43212166', 'ICT2612', '2021-02-20 13:43:00', '2021-02-20 13:47:00', 'No', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/learn_DINAH%20MOKHOMO.jpg', '2021-02-15'),
(312, '54262909', 'ICT3715', '2021-02-23 15:15:00', '2021-02-23 15:15:00', 'Yes', 'Document Upload', '', '2021-06-23'),
(316, '54288266', 'ICT3611', '2021-02-24 17:45:00', '2021-02-24 17:49:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/_layouts/15/Doc.aspx?sourcedoc=%7B04051AC6-E74B-402B-AED2-A29442CFFC5D%7D&file=Msaki_N%20B%20BUTHELEZI.docx&action=default&mobileredirect=true', '2021-10-21'),
(317, '54288266', 'ICT3642', '2021-02-24 17:49:00', '2021-02-24 17:51:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/_layouts/15/Doc.aspx?sourcedoc=%7B4B76F771-2C9F-48E0-B056-2448047405A6%7D&file=Therapy%20in%20your%2020s%20is%20very%20vital%20for%20you%20to_N%20B%20BUTHELEZI.docx&action=default&mobileredirect=true', '2021-11-19'),
(323, '46466029', 'ICT3611', '2021-02-25 15:33:00', '2021-02-25 15:36:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Claim-myUnisa-myLife-2017_B%20J%20BROWN.pdf', '2021-02-25'),
(326, '64898741', 'ICT3642', '2021-02-25 19:56:00', '2021-02-25 19:58:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/101_2021_3_b_KHANGWENI%20MULOVHEDZI.pdf', '2021-02-19'),
(328, '63878741', 'ENN1504', '2021-02-25 20:07:00', '2021-02-25 20:09:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/TUTORIAL%20101_2020_3_b_KHANGWENI%20MULOVHEDZI.pdf', '2021-02-03'),
(331, '47304413', 'ICT2611', '2021-02-26 09:47:00', '2021-02-26 09:52:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT2611-2017-10-E-1_J%20C%20ROOS.pdf', '2021-03-30'),
(335, '61315575', 'ICT3715', '2021-02-26 13:06:00', '2021-02-26 13:12:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/canasta_Nihann%20Jacobs.pdf', '2021-08-27'),
(336, '61315575', 'ICT1511', '2021-02-26 13:12:00', '2021-02-26 13:13:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/4657SOCALL0-4-2020_Nihann%20Jacobs.pdf', '2021-02-27'),
(339, '53951514', 'ICT3715', '2021-02-26 19:04:00', '2021-02-26 19:13:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/_layouts/15/Doc.aspx?sourcedoc=%7B57389A1E-D22F-4819-8DF4-6FC85710C134%7D&file=SCS%20Basic%20JCL%20-%20Student_J%20STEMMET.doc&action=default&mobileredirect=true', '2021-02-01'),
(340, '53951514', 'ICT3715', '2021-02-26 19:13:00', '2021-02-26 19:14:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/_layouts/15/Doc.aspx?sourcedoc=%7B69621669-C856-4408-9539-06C442EF5339%7D&file=SCS%20Basic%20JCL%20-%20Student_J%20STEMMET%201.doc&action=default&mobileredirect=true', '2021-02-02'),
(345, '51388944', 'ICT3641', '2021-02-27 15:01:00', '2021-02-27 15:03:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/pdf_NHLANHLA%20ERIC%20DHLAMI.pdf', '2021-02-27'),
(349, '48202177', 'ICT3715', '2021-02-28 00:52:00', '2021-02-28 00:54:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/CFE0D703-98B3-4E26-BCA3-9B6EB64A908E_NOMVULA%20THAMI%20MAHLAN.png', '2021-03-01'),
(356, '45634521', 'ICT3715', '2021-02-28 17:25:00', '2021-02-28 17:25:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/_layouts/15/Doc.aspx?sourcedoc=%7B59D5BC38-57C6-4617-9713-1F54CFC7988A%7D&file=Proctor%20-%20proof%20of%20system%20check_M%20R%20RAMOCHELE.docx&action=default&mobileredirect=true', '2021-03-01'),
(357, '45634521', 'ICT3715', '2021-02-28 17:25:00', '2021-02-28 17:29:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Schneider%20Visual%20Basic%2011E_App%20A_M%20R%20RAMOCHELE.PDF', '2021-02-24'),
(365, '59166525', 'BSM1501', '2021-03-01 04:07:00', '2021-03-01 04:17:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/GUI%20EXAM_KATLEGO%20WISEGUY%20MJAM.pdf', '2021-11-15'),
(366, '59166525', 'ICT1532', '2021-03-01 04:21:00', '2021-03-01 04:28:00', 'No', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/NETWORK%20TECHNICAL%20SKILL%20EXAM_KATLEGO%20WISEGUY%20MJAM.pdf', '2021-11-18'),
(375, '53961439', 'ICT3715', '2021-03-01 10:27:00', '2021-03-01 10:29:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/DOONA_OPEN1-1-1_Michael%20Arron%20Brown.gif', '2021-03-01'),
(376, '53961439', 'ICT2611', '2021-03-01 10:29:00', '2021-03-01 10:32:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/flatwindows81_Michael%20Arron%20Brown.jpg', '2021-03-01'),
(381, '59362111', 'ICT2613', '2021-03-01 12:40:00', '2021-03-01 12:43:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/_layouts/15/Doc.aspx?sourcedoc=%7BDCA01228-265E-48F6-972F-6A80F634EE52%7D&file=php_Tsheko%20Kutumela.docx&action=default&mobileredirect=true', '2021-03-24'),
(382, '59362111', 'ICT3611', '2021-03-01 12:43:00', '2021-03-01 12:46:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/_layouts/15/Doc.aspx?sourcedoc=%7B65EDE32C-3DD3-4A1E-A6A7-B83C2B53ABE2%7D&file=vb.net_Tsheko%20Kutumela.docx&action=default&mobileredirect=true', '2021-03-25'),
(383, '46018689', 'INF3708', '2021-03-01 14:42:00', '2021-03-01 14:43:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/_layouts/15/Doc.aspx?sourcedoc=%7BB8F9514D-70C9-4301-926C-C62FC387BF3B%7D&file=Test%20page_L%20I%20MSIBI.docx&action=default&mobileredirect=true', '2021-10-28'),
(384, '46018689', 'ICT3641', '2021-03-01 14:43:00', '2021-03-01 14:52:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Test%202_L%20I%20MSIBI.pdf', '2021-11-02'),
(387, '55527884', 'ICT3715', '2021-03-01 18:15:00', '2021-03-01 18:15:00', 'Yes', 'Document Upload', '', '2021-03-31'),
(388, '55527884', 'ICT3611', '2021-03-01 18:15:00', '2021-03-01 18:16:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/_layouts/15/Doc.aspx?sourcedoc=%7BE7C81D42-8181-4632-B6D5-1F5DFD52BA8E%7D&file=Document_2_ANDRE%20LOUIS%20DE%20LA%20HA.docx&action=default&mobileredirect=true', '2021-04-30'),
(393, '56643772', 'ICT3641', '2021-03-01 19:21:00', '2021-03-01 19:30:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT3715%20Task1_Wesley%20Otto%20Jacobs.pdf', '2021-03-26'),
(397, '40544605', 'ICT3612', '2021-03-01 19:38:00', '2021-03-01 19:40:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/FFF1DBDC-2FA2-452C-98B3-CFD068A1A2E4_B%20E%20LEVENDAL.jpeg', '2021-05-11'),
(399, '57739129', 'ICT3715', '2021-03-01 19:24:00', '2021-03-01 19:45:00', 'Yes', 'Document Upload', '', '2021-06-30'),
(403, '32899238', 'ICT3715', '2021-03-01 20:11:00', '2021-03-01 20:16:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/_layouts/15/Doc.aspx?sourcedoc=%7B2E3FD529-B640-4C7C-88FA-C4218060A52D%7D&file=3612%20MCQ_MAMANE%20OCTAVIA%20MAUBA.docx&action=default&mobileredirect=true', '2020-02-10'),
(409, '41624815', 'ICT3715', '2021-03-01 20:52:00', '2021-03-01 20:58:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/candida_neonates_MPETI%20MARTHA%20BODIBA.pdf', '2021-03-31'),
(413, '58156887', 'ICT3715', '2021-03-01 21:02:00', '2021-03-01 21:06:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Study%20Plan_MANTI%20HELEN%20NGWENYA.pdf', '2021-06-03'),
(418, '32693802', 'COS1501', '2021-03-01 21:34:00', '2021-03-01 21:35:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/101_2018_3_b_G%20OLIFANT.pdf', '2021-03-01'),
(424, '46397930', 'ICT3715', '2021-03-01 23:08:00', '2021-03-01 23:09:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/CoronaVirus_CELIA%20SEGANELE%20PHALE.pdf', '2021-03-02'),
(425, '46397930', 'ICT3611', '2021-03-01 23:09:00', '2021-03-01 23:10:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Left_Right_CELIA%20SEGANELE%20PHALE.pdf', '2021-03-24'),
(428, '63989948', 'ICT3715', '2021-03-01 23:28:00', '2021-03-01 23:30:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/63989948_ICT2632_exam_Gift%20Mthokozisi%20Sekh.pdf', '2021-04-10'),
(429, '63989948', 'ICT3715', '2021-03-01 23:30:00', '2021-03-01 23:32:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/63989948ICT2622_Gift%20Mthokozisi%20Sekh.pdf', '2021-05-04'),
(440, '44797729', 'ICT3715', '2021-03-02 07:18:00', '2021-03-02 07:21:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Mams%20Masters%20League_V%20J%20MASEKO.pdf', '2021-03-24'),
(441, '44797729', 'ICT3631', '2021-03-02 07:22:00', '2021-03-02 07:28:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/INF3708_ASSIGNMENT%2001_S2_V%20J%20MASEKO.pdf', '2021-07-15'),
(467, '54657628', 'ICT3715', '2021-03-03 23:28:00', '2021-03-03 23:35:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/_layouts/15/Doc.aspx?sourcedoc=%7B0052BC0C-2B1C-4865-9A4A-DF9FA468DCF7%7D&file=The%20Veyron_Lehlohonolo%20Mathews.docx&action=default&mobileredirect=true', '2021-10-29'),
(469, '35375132', 'ICT3715', '2021-03-04 17:46:00', '2021-03-04 17:51:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/_layouts/15/Doc.aspx?sourcedoc=%7BAE073301-F826-4BA1-AEA5-6A8387FBBDDE%7D&file=HGJBJ_K%20G%20MAAKE.docx&action=default&mobileredirect=true', '2021-03-10'),
(473, '49810529', 'ICT2613', '2021-03-04 22:16:00', '2021-03-04 22:26:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/file_2021_BONGANI%20MATSANE.pdf', '2021-03-04'),
(483, '51348020', 'ICT2611', '2021-03-07 07:30:00', '2021-03-07 07:33:00', 'No', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ict3715_MOKHUDU%20SUZAN%20MOGALE.pdf', '2021-03-11'),
(493, '51328240', 'ICT2621', '2021-03-07 11:24:00', '2021-03-07 11:29:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/_layouts/15/Doc.aspx?sourcedoc=%7BD6295DB9-8562-44E8-81D2-147C43E5C434%7D&file=Letter_COLLINS%20NYIKO%20MASHEL.docx&action=default&mobileredirect=true', '2021-03-02'),
(494, '51328240', 'ICT3641', '2021-03-07 11:45:00', '2021-03-07 11:46:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT362_COLLINS%20NYIKO%20MASHEL.pdf', '2021-03-09'),
(497, '63288761', 'ICT2622', '2021-03-07 14:01:00', '2021-03-07 14:04:00', 'Yes', 'Document Upload', '', '2021-03-01'),
(499, '51103397', 'ICT3715', '2021-03-07 15:28:00', '2021-03-07 15:30:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/SP%2020%20Speakerphone_D%20NETSHILINGANEDZA.pdf', '2021-03-01'),
(506, '60293888', 'ICT3715', '2021-03-08 09:37:00', '2021-03-08 09:44:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT3715_Tut102_updated_Jaden%20da%20Silva.pdf', '2021-10-04'),
(507, '60293888', 'ICT3612', '2021-03-08 09:44:00', '2021-03-08 09:45:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT3715_Tut102_updated_Jaden%20da%20Silva%201.pdf', '2021-10-04'),
(510, '61033979', 'ICT3715', '2021-03-08 10:31:00', '2021-03-08 10:38:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Study%20Plan_KOKETSO%20ROSE%20MANABIL.pdf', '2021-04-01'),
(520, '22845933', 'ICT3611', '2021-03-08 12:58:00', '2021-03-08 13:13:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/_layouts/15/Doc.aspx?sourcedoc=%7B2C5C77A5-A11B-4414-A389-90041247DFDB%7D&file=Assignment9_STANFORD%20NTOMBELA.docx&action=default&mobileredirect=true', '2021-11-17'),
(527, '54935369', 'ICT3621', '2021-03-08 15:34:00', '2021-03-08 15:36:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/MCQMYEXAMS_Kabelo%20Evans%20Ledimo.pdf', '2021-03-05'),
(531, '48114049', 'ICT3715', '2021-03-08 17:57:00', '2021-03-08 17:58:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/CBM_StdBankDetails_Dec2016_MATLOU%20BRIDGETTE%20MAI.pdf', '2021-11-26'),
(532, '31475167', 'ICT3611', '2021-03-08 21:06:00', '2021-03-08 21:12:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Assignment1_THOKOZANE%20MICHAEL%20MI.pdf', '2021-03-08'),
(551, '55334792', 'ICT2611', '2021-03-09 16:58:00', '2021-03-09 17:06:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/_layouts/15/Doc.aspx?sourcedoc=%7B331E49AD-B371-4679-9468-B1A0910E6809%7D&file=55334792%20upload%20task%201%20ICT3715_MABOKALE%20CHEGOFATSO.docx&action=default&mobileredirect=true', '2021-01-14'),
(558, '51548283', 'ICT3715', '2021-03-09 20:53:00', '2021-03-09 20:55:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Bethlehem%20to%20Phuthaditjaba_OLEBOGENG%20AUDICIOUS.PNG', '2021-03-01'),
(559, '53508459', 'ICT3715', '2021-03-10 16:29:00', '2021-03-10 16:31:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Study%20Plan_K%20J%20MOTLHABANE.pdf', '2021-03-10'),
(563, '54511909', 'ICT3641', '2021-03-11 18:28:00', '2021-03-11 18:31:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Public%20Servants%20Salary%20Increase%20Matter%20to%20be_SISANDA%20KIMBILI.pdf', '2021-06-16'),
(570, '40080269', 'ICT2612', '2021-03-11 22:15:00', '2021-03-11 22:18:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT2612-17S2-TUT103-Ass2_DANIEL%20ABRAHAM%20LOUW.pdf', '2021-03-08'),
(573, '41058968', 'ICT3715', '2021-03-13 10:58:00', '2021-03-13 10:59:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/_layouts/15/Doc.aspx?sourcedoc=%7B5F19E9BE-33BA-4F13-BAC9-A63DF1745A57%7D&file=Greetings_METJA%20KLAAS%20MAEFADI.docx&action=default&mobileredirect=true', '1970-12-09'),
(574, '41058968', 'ICT3611', '2021-03-13 11:01:00', '2021-03-13 11:04:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/_layouts/15/Doc.aspx?sourcedoc=%7B58FE4BF5-5523-463D-8628-9C8909B40C26%7D&file=Interests_METJA%20KLAAS%20MAEFADI.docx&action=default&mobileredirect=true', '2021-10-21'),
(580, '63288761', 'ICT3715', '2021-03-14 14:12:00', '2021-03-14 14:13:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT2631%20adj%20dates%204853TL001_3_2021_Basic_Seme_Lesego%20Violet%20Motsha.pdf', '2021-03-01'),
(595, '60977345', 'ICT2641', '2021-03-16 14:09:00', '2021-03-16 14:10:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Invoice%20Temblate_Peter%20Ntabidi%20Letsoa.pdf', '2021-03-19'),
(612, '57739129', 'ICT3612', '2021-03-18 11:14:00', '2021-03-18 11:15:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Annual%20Communication%20Letter_Sanele%20Mtshali.pdf', '2021-03-20'),
(621, '56353073', 'ICT3612', '2021-03-23 01:37:00', '2021-03-23 01:40:00', 'Yes', 'Document Upload', '', '2021-03-02'),
(629, '36565571', 'ICT3621', '2021-03-23 19:37:00', '2021-03-23 19:39:00', 'Yes', 'Document Upload', '', '2020-12-11'),
(635, '34605363', 'ICT3715', '2021-03-24 10:20:00', '2021-03-24 10:25:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/_layouts/15/Doc.aspx?sourcedoc=%7B5C3421E5-972A-435F-AF89-0F6DB51F7BF7%7D&file=Bounce%20backs%20Management%20proposal_B%20MTHEMBU.docx&action=default&mobileredirect=true', '2021-03-15'),
(640, '48615544', 'ICT3715', '2021-03-24 19:31:00', '2021-03-24 19:35:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/_layouts/15/Doc.aspx?sourcedoc=%7B04E93D2F-4C61-46D6-89AD-67AC0B92AD99%7D&file=48615544_C%20MAGUMURA.docx&action=default&mobileredirect=true', '2021-03-24'),
(646, '34802193', 'ICT2612', '2021-03-25 21:21:00', '2021-03-25 21:29:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/testing_NDIDZULAFHI%20SMIKE%20NE.pdf', '2021-03-21'),
(650, '36904988', 'ICT3715', '2021-03-27 16:27:00', '2021-03-27 16:30:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/_layouts/15/Doc.aspx?sourcedoc=%7B4ADFA776-2C09-438D-9F2E-B009B83C75B7%7D&file=55555555_MANYAKU%20PHATUDI.doc&action=default&mobileredirect=true', '2021-11-30'),
(651, '36904988', 'ICT3715', '2021-03-27 16:30:00', '2021-03-27 16:36:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/May_June_2020_ICT3631%20paper%20online_MANYAKU%20PHATUDI.pdf', '2021-11-30'),
(660, '53007328', 'ICT3715', '2021-04-01 07:33:00', '2021-04-01 08:09:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Task%201%20ICT%203715_S%20P%20PHILI.pdf', '2021-04-01'),
(664, '55422349', 'ICT3715', '2021-04-03 13:19:00', '2021-04-03 13:56:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/1498714957608_Siviwe%20Tshantshani.jpg', '2021-10-15'),
(670, '57281025', 'ICT3715', '2021-04-05 10:54:00', '2021-04-05 10:59:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT3642_Assignment_1_Semester1_2021_Mongikazi%20Magqabi.pdf', '2021-01-01'),
(673, '42849225', 'ICT2631', '2021-04-05 11:04:00', '2021-04-05 11:07:00', 'No', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/somalia-country_brief_2017-2020_MAROBO%20PHINEAS%20MOTLO.pdf', '2021-04-07'),
(675, '42849225', 'ICT3715', '2021-04-05 11:07:00', '2021-04-05 11:10:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/_layouts/15/Doc.aspx?sourcedoc=%7B97381C72-24CD-4E1D-9394-5343CA765B9D%7D&file=bole_MAROBO%20PHINEAS%20MOTLO.docx&action=default&mobileredirect=true', '2021-04-04'),
(683, '56993048', 'ICT1511', '2021-04-08 10:54:00', '2021-04-08 10:55:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Quotations_LWANDO%20SIHLANGU.pdf', '2021-04-21'),
(684, '56993048', 'ICT1512', '2021-04-08 10:58:00', '2021-04-08 10:58:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT3631%20Exam_LWANDO%20SIHLANGU.pdf', '2021-04-20'),
(703, '54511909', 'FAC1501', '2021-04-10 06:30:00', '2021-04-10 06:35:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/_layouts/15/Doc.aspx?sourcedoc=%7B0477B8B1-174C-43F6-B800-625520D3DC9E%7D&file=TAX3674_SISANDA%20KIMBILI.docx&action=default&mobileredirect=true', '2021-06-24'),
(705, '54042070', 'ICT3642', '2021-04-12 10:00:00', '2021-04-12 11:27:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ProofOfreg_T%20A%20TWALA.pdf', '2019-08-14'),
(706, '59620684', 'ICT3715', '2021-04-12 11:56:00', '2021-04-12 11:58:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/angel_1_xl_PETER%20EARL%20WILLIAM%20D.JPG', '2021-04-11'),
(707, '59620684', 'ICT2631', '2021-04-12 11:59:00', '2021-04-12 12:01:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/buda_PETER%20EARL%20WILLIAM%20D.jpg', '2020-04-14'),
(718, '56161204', 'ICT3612', '2021-04-12 22:44:00', '2021-04-12 22:45:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/chp15_THABANG%20WINNIE%20SEBOT.pdf', '2021-04-07'),
(719, '50675044', 'ICT3715', '2021-04-13 06:44:00', '2021-04-13 06:52:00', 'Yes', 'Document Upload', '', '2021-04-13'),
(720, '50675044', 'ICT3611', '2021-04-13 06:52:00', '2021-04-13 07:00:00', 'Yes', 'Document Upload', '', '2021-04-13'),
(726, '65921097', 'ICT3715', '2021-04-13 11:16:00', '2021-04-13 11:20:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Diploma_LUCKY%20NHLANHLA%20NDOBE.pdf', '2021-06-01'),
(732, '60322551', 'ICT3715', '2021-04-13 19:29:00', '2021-04-13 19:31:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/1440%20x1440%20RocoMamas_TENEAL%20MOONSAMY.jpg', '2021-11-10'),
(742, '49391933', 'ICT3715', '2021-04-14 15:30:00', '2021-04-14 15:34:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Final%20Vaccine%20literacy%20workshop%20invite%20(1)_SIVUYILE%20HAPPY%20KWAZA.pdf', '2021-04-17'),
(750, '46150587', 'ICT3715', '2021-04-14 22:34:00', '2021-04-14 22:35:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/_layouts/15/Doc.aspx?sourcedoc=%7B8A152DAA-A380-417C-8608-1077920D5A60%7D&file=Mailbox%20migration_MATOME%20AARON%20MAFARAL.docx&action=default&mobileredirect=true', '2021-04-14'),
(762, '37393901', 'ICT3715', '2021-04-15 16:21:00', '2021-04-15 16:26:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Work%20From%20Home%20Manual%20DRAFT%20V6_ZAMANI%20RICHWELL%20DUBA.pdf', '2021-04-16'),
(763, '37393901', 'ICT3642', '2021-04-15 16:26:00', '2021-04-15 16:29:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/_layouts/15/Doc.aspx?sourcedoc=%7BF3545CE7-EF3D-484D-8DD2-17255E9CD906%7D&file=Work%20From%20Home%20Manual%20DRAFT%20V4_ZAMANI%20RICHWELL%20DUBA.docx&action=default&mobileredirect=true', '2021-04-16'),
(767, '51092387', 'ICT3612', '2021-04-15 20:06:00', '2021-04-15 20:12:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT3612_EXAM_LUTENDO%20PATRIC%20NETHO.pdf', '2021-04-15'),
(772, '62835599', 'ICT3715', '2021-04-15 23:17:00', '2021-04-15 23:18:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT3715TUT102_SYLVIA%20ZANELE%20MADONS.pdf', '2021-10-15'),
(773, '62835599', 'ICT3611', '2021-04-15 23:19:00', '2021-04-15 23:20:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT3611TUT101_SYLVIA%20ZANELE%20MADONS.pdf', '2021-11-16'),
(777, '39537862', 'ICT3715', '2021-04-17 01:27:00', '2021-04-17 01:32:00', 'Yes', 'Document Upload', '', '2021-04-17'),
(778, '39537862', 'ICT3715', '2021-04-17 01:39:00', '2021-04-17 01:42:00', 'Yes', 'Document Upload', '', '2021-04-17'),
(779, '39537862', 'ICT3641', '2021-04-17 01:44:00', '2021-04-17 01:45:00', 'Yes', 'Document Upload', '', '2021-04-17'),
(781, '39537862', 'ICT3715', '2021-04-17 01:52:00', '2021-04-17 01:52:00', 'Yes', 'Document Upload', '', '2021-04-17'),
(782, '39537862', 'ICT3715', '2021-04-17 01:53:00', '2021-04-17 01:56:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/INF3708_ASSIGNMENT_02_MEMO_2020_S1_MAKHUTA%20MARIA%20MOLOTO.pdf', '2021-04-17'),
(784, '53043537', 'ICT3612', '2021-04-17 22:58:00', '2021-04-17 23:00:00', 'No', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Rachael%20Nomhlekabo%20Mahlangu%20CV_RACHAEL%20NOMHLEKABO%20M.pdf', '2021-05-28'),
(788, '55923542', 'ICT3715', '2021-04-18 17:29:00', '2021-04-18 17:39:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT3641_Sol_3_Semester_2_2018_SBABALWE%20HANISE.pdf', '2021-04-18'),
(789, '55923542', 'ICT3621', '2021-04-18 17:45:00', '2021-04-18 17:45:00', 'Yes', 'Document Upload', '', '2021-04-18'),
(795, '61384380', 'ICT3631', '2021-04-19 06:49:00', '2021-04-19 06:50:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/4911SOCALL0-4-2021_MAPULA%20JACQUOLINE%20RA.pdf', '2021-11-30'),
(796, '45319855', 'ICT3611', '2021-04-19 06:50:00', '2021-04-19 06:52:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Nols_Silulami%20Peter-Ray%20B.pdf', '2021-04-23'),
(798, '45628961', 'ICT3641', '2021-04-19 06:52:00', '2021-04-19 06:58:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Nols_Silulami%20Peter-Ray%20B%201.pdf', '2021-04-28'),
(804, '51557355', 'INF3708', '2021-04-19 10:15:00', '2021-04-19 10:16:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Screenshot_20210418_111939_com.twitter.androi_PERTUNIA%20HAPPY%20MOLOP.jpg', '2021-04-23'),
(805, '51557355', 'FAC1501', '2021-04-19 10:16:00', '2021-04-19 10:17:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/testimonial%20letter_PERTUNIA%20HAPPY%20MOLOP.pdf', '2021-05-20'),
(817, '46418474', 'ICT3715', '2021-04-20 14:16:00', '2021-04-20 14:20:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/_layouts/15/Doc.aspx?sourcedoc=%7B87D30BCC-0C30-4FE7-84A0-46B22540E649%7D&file=46418474%20-%20D%20Pillay%20-%20Task%201_01_D%20PILLAY.docx&action=default&mobileredirect=true', '2021-05-03'),
(818, '46418474', 'INF3708', '2021-04-20 14:20:00', '2021-04-20 14:21:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/_layouts/15/Doc.aspx?sourcedoc=%7B1F84C584-4738-438E-838A-7E7F4BACCCAF%7D&file=46418474%20-%20D%20Pillay%20-%20Task%201_02_D%20PILLAY.docx&action=default&mobileredirect=true', '2021-05-04'),
(822, '59258497', 'ICT3611', '2021-04-20 15:39:00', '2021-04-20 15:40:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Screenshot_20210420-151921_Arnold%20Sifiso%20Mabaso.jpg', '2021-10-29'),
(826, '54059682', 'ICT3642', '2021-04-20 20:03:00', '2021-04-20 20:07:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ACCUMULATION_N%20C%20NKUNA.png', '2021-04-20'),
(830, '37085603', 'ICT3612', '2021-04-21 13:34:00', '2021-04-21 13:37:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT3715_Tut102_updated_LANDIWE%20MPUKU.pdf', '2021-04-21'),
(831, '37085603', 'ICT3612', '2021-04-21 13:38:00', '2021-04-21 13:43:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT3612_103_1_2018_LANDIWE%20MPUKU.pdf', '2021-04-21'),
(833, '64211592', 'ICT2632', '2021-04-22 03:27:00', '2021-04-22 03:28:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/2021-04-22%2003_24_56-_R%20MAJOLA.png', '2020-06-12');
INSERT INTO `examinations` (`id`, `student_number`, `module_code`, `start_time`, `completion_time`, `declaration`, `exam_type`, `uploads`, `exam_date`) VALUES
(838, '36833118', 'ICT3715', '2021-04-22 14:00:00', '2021-04-22 14:02:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/_layouts/15/Doc.aspx?sourcedoc=%7B4505C970-4481-4D48-9D6A-940314E01EC1%7D&file=PDF%20upload_F%20S%20MOSHOADIBA.docx&action=default&mobileredirect=true', '2021-04-22'),
(846, '46148302', 'ICT3715', '2021-04-22 16:45:00', '2021-04-22 16:46:00', 'Yes', 'Document Upload', '', '2021-04-22'),
(859, '64270718', 'ICT3715', '2021-04-23 19:38:00', '2021-04-23 19:43:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/ICT3715_Assignment_01%201_THELMA%20KHOROMMBI.pdf', '2021-04-23'),
(865, '57452210', 'ICT3612', '2021-04-26 22:10:00', '2021-04-26 22:11:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/_layouts/15/Doc.aspx?sourcedoc=%7B05AFDEB1-B1B4-48BE-9F26-F078FCB0FEB2%7D&file=binary_VUYISEKA%20NOMFUNEKO%20M.docx&action=default&mobileredirect=true', '2021-06-06'),
(870, '32901046', 'ICT3642', '2021-04-26 22:51:00', '2021-04-26 22:55:00', 'No', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/_layouts/15/Doc.aspx?sourcedoc=%7B28DA1770-6C61-428E-8393-57531E08DA28%7D&file=32901046_ICT3642_ASSIGNMENT3_N%20M%20MASEKO.docx&action=default&mobileredirect=true', '2021-04-29'),
(887, '56941773', 'ICT3715', '2021-04-27 18:12:00', '2021-04-27 18:13:00', 'No', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Unisa_Logo_University_of_South_Africa_MATIMBA%20COLLEN%20KONJA.png', '2021-04-28'),
(890, '43716032', 'ICT3715', '2021-04-27 19:14:00', '2021-04-27 19:16:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Test%20document_A%20D%20ALEXANDER.pdf', '2021-11-04'),
(893, '64317765', 'ICT1513', '2021-04-27 19:37:00', '2021-04-27 19:41:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Assignment%201%20Semester%201%202021%20ICT3631_MANDISA%20NKOSINATHI%20M.pdf', '2021-04-27'),
(900, '56997914', 'ENN1504', '2021-04-28 14:15:00', '2021-04-28 14:20:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Database%20Error_EVIDANCE%20SITHOLE.PNG', '2044-04-28'),
(904, '59012552', 'ICT3715', '2021-04-28 15:26:00', '2021-04-28 15:31:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Study%20fees%20quotation_Paul%20Pierre%20Van%20der.pdf', '2021-04-28'),
(908, '55437451', 'ICT1521', '2021-04-28 19:41:00', '2021-04-28 19:45:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/CPD%20network_ANNAH%20BASEBI%20MESHE.pdf', '2021-04-28'),
(909, '55437451', 'ICT2632', '2021-04-28 19:45:00', '2021-04-28 19:47:00', 'No', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Excercise%202.3_ANNAH%20BASEBI%20MESHE.pdf', '2021-04-28'),
(914, '47562781', 'INF3708', '2021-04-29 08:59:00', '2021-04-29 09:02:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Invoice%20%23%2020201003-40_NYELETI%20LILIAN%20NDALA.pdf', '2021-04-29'),
(915, '57139725', 'ICT3715', '2021-04-29 15:59:00', '2021-04-29 16:03:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Task1%20Document%201_KELWIN%20JOHANNES%20FRIT.jpg', '2021-11-29'),
(916, '57139725', 'INF3708', '2021-04-29 16:04:00', '2021-04-29 16:07:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/_layouts/15/Doc.aspx?sourcedoc=%7BE27D7438-01DB-4774-B9DD-831BD531307C%7D&file=Task1%20Document%202_KELWIN%20JOHANNES%20FRIT.docx&action=default&mobileredirect=true', '2021-05-26'),
(917, '50499955', 'ICT3715', '2021-04-29 16:18:00', '2021-04-29 16:23:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/_layouts/15/Doc.aspx?sourcedoc=%7BF8EE2618-F304-4C92-8D00-715663224439%7D&file=UNISA_G%20J%20RIETH.docx&action=default&mobileredirect=true', '2021-04-30'),
(918, '50499955', 'ICT3621', '2021-04-29 16:24:00', '2021-04-29 16:24:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/_layouts/15/Doc.aspx?sourcedoc=%7B31DDB346-7AEC-4D70-9CFC-30B3D03A464E%7D&file=UNISA_G%20J%20RIETH%201.docx&action=default&mobileredirect=true', '2021-05-27'),
(923, '47562781', 'ICT3715', '2021-04-29 19:33:00', '2021-04-29 20:37:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/HRMC%2048%20of%202020_NYELETI%20LILIAN%20NDALA.pdf', '2021-04-30'),
(924, '47562781', 'ICT3715', '2021-04-29 20:37:00', '2021-04-29 20:40:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/HRMC%2049%20of%202020_NYELETI%20LILIAN%20NDALA.pdf', '2021-04-30'),
(934, '49301500', 'ICT2632', '2021-04-30 19:38:00', '2021-04-30 19:38:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/49301500_ICT2611_03_REUBEN%20MOJAKI%20MOKERE.PDF', '2021-04-14'),
(937, '62142941', 'ICT2622', '2021-04-30 21:58:00', '2021-04-30 22:01:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Homemade-Beef-Stew_Mmaselaelo%20Thapelo%20R.pdf', '2021-05-19'),
(945, '45015945', 'ICT3715', '2021-05-01 21:35:00', '2021-05-01 21:37:00', 'Yes', 'Document Upload', 'https://mylifeunisaac.sharepoint.com/sites/ICT3715-Admin/Shared%20Documents/Apps/Microsoft%20Forms/UNISA%20EXAM%20PORTAL/Question%201/Model%20driven%20App_N%20O%20SIBEDE.pdf', '2021-05-01');

-- --------------------------------------------------------

--
-- Table structure for table `modules`
--

CREATE TABLE `modules` (
  `module_code` varchar(7) NOT NULL,
  `module_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `modules`
--

INSERT INTO `modules` (`module_code`, `module_name`) VALUES
('BSM1501', 'Business Management IA'),
('COS1501', 'Theoretical Computer Science'),
('ENN1504', 'Practising Workplace  English'),
('FAC1501', 'Introductory Financial Accounting'),
('ICT1511', 'Introduction to  Programming'),
('ICT1512', 'Introduction to Interactive Programming'),
('ICT1513', 'Introduction to Web Design'),
('ICT1521', 'Introduction to Databases'),
('ICT1532', 'Network Technical Skill'),
('ICT2611', 'Graphical user Interface Programming'),
('ICT2612', 'Interactive Programming'),
('ICT2613', 'Internet Programming'),
('ICT2621', 'Structured System Analysis Design'),
('ICT2622', 'Object-Oriented Analysis'),
('ICT2631', 'Operation System Practice'),
('ICT2632', 'Digital Logic'),
('ICT2641', 'Business Informatics IIA'),
('ICT3611', 'Advanced Graphical user Interface'),
('ICT3612', 'Advanced Internet Programming'),
('ICT3621', 'Database Design'),
('ICT3631', 'Advanced Operating System Practice'),
('ICT3641', 'Business Infromatics IIIA'),
('ICT3642', 'Business Infromatics IIIB'),
('ICT3715', 'Information and Communication Technology'),
('ICT3722', 'Database Practice'),
('INF3708', 'Software Project Management');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `student_number` varchar(8) NOT NULL,
  `student_name` varchar(100) DEFAULT NULL,
  `student_surname` varchar(100) DEFAULT NULL,
  `student_email` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`student_number`, `student_name`, `student_surname`, `student_email`) VALUES
('22845933', 'Stanford', 'Ntombela', '48615293@mylife.unisa.ac.za'),
('31281745', 'Kubashnee', 'Pillay', '31281745@mylife.unisa.ac.za'),
('31475167', 'Thokozane', 'Miya', '31475167@mylife.unisa.ac.za'),
('32693802', 'Godfrey', 'Olifant', '49844458@mylife.unisa.ac.za'),
('32899238', 'Mamane', 'Maubane', '32899238@mylife.unisa.ac.za'),
('32901046', 'Ntombizodwa Mabel', 'Maseko', '32901046@mylife.unisa.ac.za'),
('34605363', 'Boni', 'Mthembu', '34605363@mylife.unisa.ac.za'),
('34802193', 'Ndidzulafi', 'Nandzelele', '34802193@mylife.unisa.ac.za'),
('35375132', 'Kgaugelo', 'Maake', '35375132@mylife.unisa.ac.za'),
('36565571', 'Muela', 'Mujinga', '36565571@mylife.unisa.ac.za'),
('36833118', 'Faith', 'Moshoadiba', '36833118@mylife.unisa.ac.za'),
('36904988', 'Manyaku', 'Phatudi', '36904988@mylife.unisa.ac.za'),
('37027166', 'Devendhra', 'Naran', '37027166@mylife.unisa.ac.za'),
('37085603', 'Landiwe', 'Mpuku', '37085603@mylife.unisa.ac.za'),
('37393901', 'Zamani', 'Dubazana', '37393901@mylife.unisa.ac.za'),
('39396363', 'Nishan', 'Pillay', '39396363@mylife.unisa.ac.za'),
('39537862', 'Makhuta', 'Moloto', '39537862@mylife.unisa.ac.za'),
('40080269', 'Daniel', 'Louw', '40080269@mylife.unisa.ac.za'),
('40544605', 'Brigitte', 'Levendal', '40544605@mylife.unisa.ac.za'),
('40878430', 'Reealan', 'Moodley', '40878430@mylife.unisa.ac.za'),
('41058968', 'Metja Klaas', 'Maefadi', '41058968@mylife.unisa.ac.za'),
('41624815', 'Martha', 'Bodiba', '41624815@mylife.unisa.ac.za'),
('42198674', 'Zama', 'Ngcobo', '42198674@mylife.unisa.ac.za'),
('42363136', 'Nhlanhla', 'Kgatle', '42363136@mylife.unisa.ac.za'),
('42849225', 'Phineas', 'Motloutsi', '42849225@mylife.unisa.ac.za'),
('43212166', 'Dinah', 'Mokhomo', '43212166@mylife.unisa.ac.za'),
('43716032', 'Ashley', 'Alexander', '43716032@mylife.unisa.ac.za'),
('44512406', 'Yusuf', 'Amod', '44512406@mylife.unisa.ac.za'),
('44797729', 'Vuyiswa', 'Maseko', '44797729@mylife.unisa.ac.za'),
('44974825', 'Gary', 'Cummings', '44974825@mylife.unisa.ac.za'),
('45015945', 'Nditsheni Osca', 'Sibede', '45015945@mylife.unisa.ac.za'),
('45319855', 'Silulami', 'Sokufudumala', '45319855@mylife.unisa.ac.za'),
('45628961', 'Peter-Ray', 'Sokufudumala', '45319855@mylife.unisa.ac.za'),
('45634521', 'Relebohile Mary-Monica', 'Ramochele', '45634521@mylife.unisa.ac.za'),
('45693315', 'Rhandzu', 'Rikhotso', '45693315@mylife.unisa.ac.za'),
('46018689', 'Lungi', 'Msibi', '46018689@mylife.unisa.ac.za'),
('46148302', 'Tshepo Brian', 'Mulaudzi', '46148302@mylife.unisa.ac.za'),
('46150587', 'Matome', 'Mafaralala', '46150587@mylife.unisa.ac.za'),
('46240314', 'Lungelo', 'Madiya', '46240314@mylife.unisa.ac.za'),
('46397930', 'Celia', 'Phale', '46397930@mylife.unisa.ac.za'),
('46418474', 'Dion', 'Pillay', '46418474@mylife.unisa.ac.za'),
('46466029', 'Bryan', 'Brown', '46466029@mylife.unisa.ac.za'),
('47275154', 'Phillip', 'Odendaal', '47275154@mylife.unisa.ac.za'),
('47304413', 'Jodie', 'Roos', '47304413@mylife.unisa.ac.za'),
('47562781', 'Nyeleti', 'Ndala', '47562781@mylife.unisa.ac.za'),
('48114049', 'Matlou Bridgette', 'Maila', '48114049@mylife.unisa.ac.za'),
('48202177', 'Nomvula Thami', 'Mahlangu', '48202177@mylife.unisa.ac.za'),
('48208124', 'Rudolph', 'Kaywa', '48208124@mylife.unisa.ac.za'),
('48615544', 'Cynthia', 'Magumura', '48615544@mylife.unisa.ac.za'),
('49301500', 'Reuben', 'Mokeretla', '49301500@mylife.unisa.ac.za'),
('49391933', 'Sivuyile Happy', 'Kwaza', '49391933@mylife.unisa.ac.za'),
('49810529', 'Bongani', 'Matsane', '49810529@mylife.unisa.ac.za'),
('50178695', 'Paulos', 'Mogale', '50178695@mylife.unisa.ac.za'),
('50319477', 'Daniel', 'Mbedla', '50319477@mylife.unisa.ac.za'),
('50424653', 'Kenalemang', 'Kopang', '50424653@mylife.unisa.ac.za'),
('50499955', 'Gavilan', 'Rieth', '50499955@mylife.unisa.ac.za'),
('50675044', 'Mahlatse', 'Moreku', '50675044@mylife.unisa.ac.za'),
('51092387', 'Lutendo Patric', 'Nethononda', '51092387@mylife.unisa.ac.za'),
('51103397', 'Dakalo', 'Netshidza', '51103397@mylife.unisa.ac.za'),
('51328240', 'Collins Nyiko', 'Mashele', '51328240@mylife.unisa.ac.za'),
('51348020', 'Mokhudu Suzan', 'Mogale', '51348020@mylife.unisa.ac.za'),
('51388944', 'Nhlanhla', 'Dhlamini', '51388944@mylife.unisa.ac.za'),
('51548283', 'Olebogeng', 'Mahlonoko', '51548283@mylife.unisa.ac.za'),
('51557355', 'Pertunia Happy', 'Molope', '51557355@mylife.unisa.ac.za'),
('51837862', 'Dangisa Ignitious', 'Shiburi', '51837862@mylife.unisa.ac.za'),
('51856867', 'Eric', 'Friedenthal', '51856867@mylife.unisa.ac.za'),
('51972964', 'Matthew', 'Pinto', '51972964@mylife.unisa.ac.za'),
('53007328', 'Sandise', 'Phili', '53007328@mylife.unisa.ac.za'),
('53043537', 'Rachael', 'Mahlangu', '53043537@mylife.unisa.ac.za'),
('53436164', 'Katlego', 'Namola', '53436164@mylife.unisa.ac.za'),
('53508459', 'Kabelo', 'Motlhabane', '53508459@mylife.unisa.ac.za'),
('53951514', 'Juandre', 'Stemmet', '53951514@mylife.unisa.ac.za'),
('53961439', 'Michael', 'Brown', '53961439@mylife.unisa.ac.za'),
('54042070', 'Tebogo', 'Twala', '54042070@mylife.unisa.ac.za'),
('54059682', 'Ntando', 'Nkuna', '54059682@mylife.unisa.ac.za'),
('54262909', 'Jascenovin', 'Prins', '54262909@mylife.unisa.ac.za'),
('54288266', 'Nosipho', 'Buthelezi', '54288266@mylife.unisa.ac.za'),
('54511909', 'Sibabalwe', 'Kimbili', '54511909@mylife.unisa.ac.za'),
('54657628', 'Lehlohonolo', 'Lekhelebane', '54657628@mylife.unisa.ac.za'),
('54709695', 'Thamsanqa', 'Lunga', '54709695@mylife.unisa.ac.za'),
('54803977', 'Pieter', 'Skhosana', '54803977@mylife.unisa.ac.za'),
('54811163', 'Hendrik', 'Kruger', '54811163@mylife.unisa.ac.za'),
('54935369', 'Kabelo', 'Ledimo', '54935369@mylife.unisa.ac.za'),
('55334792', 'Chego', 'Makuwa', '55334792@mylife.unisa.ac.za'),
('55422349', 'Siviwe', 'Tshantshani', '55422349@mylife.unisa.ac.za'),
('55437451', 'Annah', 'Meshe', '55437451@mylife.unisa.ac.za'),
('55527884', 'Andre', 'De La Harpe', '55527884@mylife.unisa.ac.za'),
('55796257', 'Neall', 'Siems', '55796257@mylife.unisa.ac.za'),
('55923542', 'Sbabalwe', 'Hanise', '55923542@mylife.unisa.ac.za'),
('56161204', 'Thabang', 'Sebothoma', '56161204@mylife.unisa.ac.za'),
('56233590', 'Tarren', 'Seage', '56233590@mylife.unisa.ac.za'),
('56353073', 'Makhosazana', 'Mkhatshwa', '56353073@mylife.unisa.ac.za'),
('56605234', 'Kurt', 'Rustin', '56605234@mylife.unisa.ac.za'),
('56643772', 'Wesley', 'Jacobs', '56643772@mylife.unisa.ac.za'),
('56693141', 'Portia', 'Nyathi', '56693141@mylife.unisa.ac.za'),
('56891326', 'Mahesh', 'Jina', '56891326@mylife.unisa.ac.za'),
('56941773', 'Matimba', 'Konjane', '56941773@mylife.unisa.ac.za'),
('56993048', 'Lwando', 'Sihlangu', '56993048@mylife.unisa.ac.za'),
('56997914', 'Evidance', 'Sithole', '56997914@mylife.unisa.ac.za'),
('57100012', 'Dominique', 'Kayitare', '57100012@mylife.unisa.ac.za'),
('57139725', 'Kelwin', 'Fritz', '57139725@mylife.unisa.ac.za'),
('57281025', 'Mongikazi', 'Magqabi', '57281025@mylife.unisa.ac.za'),
('57452210', 'Vuyiseka', 'Magazi', '57452210@mylife.unisa.ac.za'),
('57739129', 'Sanele', 'Mtshali', '57739129@mylife.unisa.ac.za'),
('58156887', 'Manti', 'Ngwenya', '58156887@mylife.unisa.ac.za'),
('58160329', 'Asanda', 'Matini', '58160329@mylife.unisa.ac.za'),
('59012552', 'Paul', 'Van Der Merwe', '59012552@mylife.unisa.ac.za'),
('59079541', 'Tshilewu Gael', 'Mutombo', '59079541@mylife.unisa.ac.za'),
('59166525', 'Katlego', 'Mjamba', '59166525@mylife.unisa.ac.za'),
('59258497', 'Sifiso', 'Mabaso', '59258497@mylife.unisa.ac.za'),
('59362111', 'Tsheko', 'Kutumela', '59362111@mylife.unisa.ac.za'),
('59376430', 'Yannick Mfunyi', 'Kankolongo', '59376430@mylife.unisa.ac.za'),
('59620684', 'Peter', 'Dickson', '59620684@mylife.unisa.ac.za'),
('60293888', 'Jaden', 'Da Silva', '60293888@mylife.unisa.ac.za'),
('60322551', 'Teneal', 'Moonsamy', '60322551@mylife.unisa.ac.za'),
('60635495', 'Matshediso Eugenia', 'Sehlabo', '60635495@mylife.unisa.ac.za'),
('60977345', 'Peter', 'Letsoalo', '60977345@mylife.unisa.ac.za'),
('61033979', 'Koketso', 'Manabile', '61033979@mylife.unisa.ac.za'),
('61315575', 'Nihann', 'Jacobs', '61315575@mylife.unisa.ac.za'),
('61384380', 'Mmapula', 'Rammutla', '61384380@mylife.unisa.ac.za'),
('62142941', 'Thapelo', 'Rapatje', '62142941@mylife.unisa.ac.za'),
('62441302', 'Lethabo Ngoakwana', 'Mothemane', '62441302@mylife.unisa.ac.za'),
('62732765', 'Ardlight', 'Gutukunuhwa', '62732765@mylife.unisa.ac.za'),
('62835599', 'Sylvia', 'Madonsela', '62835599@mylife.unisa.ac.za'),
('62993062', 'Leonard Lehlohonolo', 'Mokokolisi', '62993062@mylife.unisa.ac.za'),
('63288761', 'Lesego', 'Motshabi', '63288761@mylife.unisa.ac.za'),
('63878741', 'Khangweni', 'Mulovhedzi', '64898741@mylife.unisa.ac.za'),
('63989948', 'Gift Mthokozisi', 'Sekhosana', '63989948@mylife.unisa.ac.za'),
('64211592', 'Reitumetse', 'Majola', '64211592@mylife.unisa.ac.za'),
('64270718', 'Thelma', 'Khorommbi', '64270718@mylife.unisa.ac.za'),
('64317765', 'Nkosinathi', 'Mkhize', '64317765@mylife.unisa.ac.za'),
('64360342', 'Nonhlakanipho', 'Phiri', '64360342@mylife.unisa.ac.za'),
('64898741', 'Khangweni', 'Mulovhedzi', '64898741@mylife.unisa.ac.za'),
('65921097', 'Nhlanhla', 'Ndobe', '65921097@mylife.unisa.ac.za'),
('student_', 'sudent_name', 'student_surname', 'student_email');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `enrollments`
--
ALTER TABLE `enrollments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `module_code` (`module_code`),
  ADD KEY `student_number` (`student_number`);

--
-- Indexes for table `examinations`
--
ALTER TABLE `examinations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_number` (`student_number`),
  ADD KEY `module_code` (`module_code`);

--
-- Indexes for table `modules`
--
ALTER TABLE `modules`
  ADD PRIMARY KEY (`module_code`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`student_number`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `enrollments`
--
ALTER TABLE `enrollments`
  ADD CONSTRAINT `enrollments_ibfk_1` FOREIGN KEY (`module_code`) REFERENCES `modules` (`module_code`),
  ADD CONSTRAINT `enrollments_ibfk_2` FOREIGN KEY (`student_number`) REFERENCES `students` (`student_number`);

--
-- Constraints for table `examinations`
--
ALTER TABLE `examinations`
  ADD CONSTRAINT `examinations_ibfk_1` FOREIGN KEY (`student_number`) REFERENCES `students` (`student_number`),
  ADD CONSTRAINT `examinations_ibfk_2` FOREIGN KEY (`module_code`) REFERENCES `modules` (`module_code`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
