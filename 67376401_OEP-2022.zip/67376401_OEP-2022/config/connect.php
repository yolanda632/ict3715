<?php
//connecting to database

abstract class Database {
	private $dsn =  "mysql:host=localhost; dbname=";
	private $db_name = "oep";
	private $username = "root";
	private $password = "";
	private $pdo = null;

	private function connectionString() {
		try {
			$this->pdo = new PDO($this->dsn.$this->db_name, $this->username, $this->password);
		}
		catch(PDOException $ex) {
			echo $ex->getMessage();
		}
		return $this->pdo;
	}

	public function connect() {
		return $this->connectionString();
	}
}

?>