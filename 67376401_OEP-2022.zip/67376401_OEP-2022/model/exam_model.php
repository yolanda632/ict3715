<?php

/**
 * 
 */
class Exams extends Database {
	private $dbcon = null;

	public function __construct() {
		$this->dbcon = parent::connect();
	}
	
	public function getCurrentExams($studenNumber) {
		$statement = $this->dbcon->prepare("SELECT * FROM `enrollments` 
											WHERE `student_number` = ? AND `module_code` 
											IN (SELECT `examinfo`.`module_code` FROM `examinfo`) ");
		$statement->bindValue(1, $studenNumber);
		$statement->execute();
		$statement->rowCount();
		return $statement->fetchAll(PDO::FETCH_OBJ);
	}

	public function getAllExams() {
		$statement = $this->dbcon->prepare("SELECT * FROM `examinfo` ORDER BY exam_date DESC");
		$statement->execute();
		$statement->rowCount();
		return $statement->fetchAll(PDO::FETCH_OBJ);
	}

	public function addNewExam($data) {
		$statement = $this->dbcon->prepare("INSERT INTO `examinfo`(`module_code`, `exam_date`, `start_time`, `completion_time`, `exam_type`, `upload`) 
											VALUES (:moduleCode, :examDate, :examTimeStart, :examTimeEnd, :examType, :file_path) ");
		$results = $statement->execute([
			':moduleCode' => $data['moduleCode'],
			':examDate' => $data['examDate'],
			':examTimeStart' => $data['examTimeStart'],
			':examTimeEnd' => $data['examTimeEnd'],
			':examType' => $data['examType'],
			':file_path' => $data['exam_paper'],
		]);
		if($results) {
			return true;
		}
		else {
			return false;
		}
	}

	public function updatingExam($data) {
		$statement = $this->dbcon->prepare("UPDATE `examinfo` 
											SET `module_code`=[value-2],`exam_date`=[value-3],`start_time`=[value-4],`completion_time`=[value-5],`exam_type`=[value-6],`upload`=[value-7] 
											WHERE `id`=[value-1]" );
		$results = $statement->execute([
			':moduleCode' => $data['moduleCode'],
			':examDate' => $data['examDate'],
			':examTimeStart' => $data['examTimeStart'],
			':examTimeEnd' => $data['examTimeEnd'],
			':examType' => $data['examType'],
			':file_path' => $data['exam_paper'],
			':examID' => $data['examID'],
		]);
		if($results) {
			return true;
		}
		else {
			return false;
		}
	}

	public function getExamByID($examID) {
		$statement = $this->dbcon->prepare("SELECT * FROM `examinfo` WHERE id = ? ");
		$statement->bindValue(1, $examID);
		$statement->execute();
		$statement->rowCount();
		return $statement->fetch(PDO::FETCH_OBJ);
	}

	public function getExamInfo($examID) {
		$statement = $this->dbcon->prepare("SELECT * FROM `examinfo` WHERE module_code = ? ORDER BY exam_date DESC");
		$statement->bindValue(1, $examID);
		$statement->execute();
		$statement->rowCount();
		return $statement->fetch(PDO::FETCH_OBJ);
	}

	public function searchExams($searchTerm) {
		$searchTerm = "%".$searchTerm."%";
		$statement = $this->dbcon->prepare("SELECT * FROM `examinfo` WHERE module_code LIKE ? ");
		$statement->bindValue(1, $searchTerm);
		$statement->execute();
		if($statement->rowCount()) {
			return $statement->fetchAll(PDO::FETCH_OBJ);
		}
		else {
			return false;
		}
	}

	public function studentExamSubmit($data) {
		$statement = $this->dbcon->prepare(" INSERT INTO `examinations`(`student_number`, `module_code`, `exam_date`, `declaration`, `uploads`) 
											VALUES (:studentID, :module_code, :examDate, :declaration, :file_upload) ");
		$results = $statement->execute([
			':studentID' => $data['studentID'],
			':module_code' => $data['module_code'],
			':examDate' => $data['examDate'],
			':declaration' => $data['declaration'],
			':file_upload' => $data['file_upload'],
		]);
		if($results) {
			return true;
		}
		else {
			return false;
		}
	}

	public function isExamWritten($studentID, $moduleCode) {
		$files = scandir("exams/submissions/");
		//removed folder navigation (. & ..) 
		array_shift($files);
		array_shift($files);
		// 
		$response = false;
		foreach($files as $file) {
			$segments = explode('_', $file); //split file data, when encounter (_)
			if($segments[0] == $studentID && $segments[1] == $moduleCode && substr($segments[3], 0, -4) <= date('Y-m-d')) {
				$response = true;			}
			else {
				$response = false;
				//$segments[0].'#'.$segments[1].'#'.substr($segments[3], 0, -4);
			}
		}
		return $response;
	}
	//model to send email notification to student
	public function sendMail($studentEmail='') {
		if(file_exists("PHPMailer/PHPMailerAutoload.php")) {
			require_once('PHPMailer/PHPMailerAutoload.php');
			$mail = new PHPMailer();
		}
		
		$message = "Dear Student, <br><br>An exam submitted by you to North University was successfully received and recorded. <br>Contact University for more information.";

		//Mail Server Connection Settings
		$mail->isSMTP();                     // Set mailer to use SMTP
		$mail->Host = 'smtp.gmail.com';		//'baratheon.aserv.co.za; mail.crustforex.co.za';  // Specify main and backup SMTP servers
		$mail->SMTPAuth = true;               // Enable SMTP authentication
		$mail->Username = 'TYPE_YOUR_EMAIL_HERE';   // SMTP username
		$mail->Password = 'TYPE_YOUR_PASSWORD_HERE';            // SMTP password
		$mail->SMTPSecure = 'tls'; //'tls';        // Enable TLS encryption, `ssl` also accepted
		$mail->Port = 587; //465; //587;			// TCP port to connect to

		$to = $studentEmail; // recepient email addr
		$from = 'TYPE_YOUR_EMAIL_HERE'; //'gopolangpascaline@gmail.com'; sender email addr
		$message = nl2br($message);

		$mail->From      = $from; //From address
		$mail->AddAddress ( $to );	  //email to send to
		//$mail->addReplyTo( $email ); //address to show replyTo
		$mail->isHTML(true);
		$mail->FromName  = 'Web Notification'; //default name it can be changed
		$mail->Subject   = "Exam Notification";  //mail subject
		$mail->Body      = $message;  //message body
		
		if($mail->Send()) { //now send the email
			#echo "<script>alert('Your email message was sent!')</script>"; //if email was sent show message
			return true;
		} else {
			#echo "<script>alert('Sorry Failed to send message!')</script>"; //if email fail sending throw message
			return false;
		}
	}

}


?>