<?php


/**
 * 
 */
class Lecture extends Database {
	private $dbcon = null;

	public function __construct() {
		$this->dbcon = parent::connect();
	}

	public function login($email, $password) {
		$statement = $this->dbcon->prepare("SELECT * FROM `admin` WHERE email = ? AND password = ? ");
		$statement->bindValue(1, $email);
		$statement->bindValue(2, sha1($password) );
		$statement->execute();
		if($statement->rowCount() > 0) {
			$_SESSION['lecture']['token'] = sha1(uniqid());
			return true;
		}
		else {
			return false;		
		}
	}

	public function logout() {
		unset($_SESSION['lecture']);
		return true;
	}

	public function isAuthorized() {
		return (isset($_SESSION['lecture']['token'])) ? true : false;
	}
	
}

?>