<?php


/**
 * 
 */
class Student extends Database {
	private $dbcon = null;

	public function __construct() {
		$this->dbcon = parent::connect();
	}

	public function login($email, $lastname) {
		$statement = $this->dbcon->prepare("SELECT * FROM `students` WHERE student_email = ? AND student_surname = ? ");
		$statement->bindValue(1, $email);
		$statement->bindValue(2, $lastname);
		$statement->execute();
		if($statement->rowCount()) {
			$row = $statement->fetch(PDO::FETCH_OBJ);
			$_SESSION['student']['email'] = $row->student_email;
			$_SESSION['student']['token'] = sha1(uniqid());
			return true; 
		}
		else {
			return false;
		}	
	}

	public function logout() {
		unset($_SESSION['student']);
		return true;
	}

	public function isAuthorized() {
		return (isset($_SESSION['student']['token'])) ? true : false;
	}

	public function getAllStudent() {
		$statement = $this->dbcon->prepare("SELECT * FROM `students` ");
		$statement->execute();
		if($statement->rowCount()) {
			return $statement->fetchAll(PDO::FETCH_OBJ);
		}
		else {
			return false;
		}
	}

	public function getStudentByID($studentID) {
		$statement = $this->dbcon->prepare("SELECT * FROM `students` WHERE student_number = ? ");
		$statement->bindValue(1, $studentID);
		$statement->execute();
		if($statement->rowCount()) {
			return $statement->fetch(PDO::FETCH_OBJ);
		}
		else {
			return false;
		}
	}

	public function searchStudent($searchTerm) {
		$statement = $this->dbcon->prepare("SELECT * FROM `students` WHERE student_number LIKE ? OR student_name LIKE ? OR student_surname LIKE ?");
		$statement->bindValue(1, $searchTerm);
		$statement->bindValue(2, $searchTerm);
		$statement->bindValue(3, $searchTerm);
		$statement->execute();
		if($statement->rowCount()) {
			return $statement->fetchAll(PDO::FETCH_OBJ);
		}
		else {
			return false;
		}
	}


}

?>