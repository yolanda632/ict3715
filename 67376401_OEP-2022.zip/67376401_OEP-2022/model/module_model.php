<?php

/**
 * 
 */
class Module extends Database {
	private $dbcon = null;

	public function __construct() {
		$this->dbcon = parent::connect();
	}

	public function getModules() {
		$statement = $this->dbcon->prepare("SELECT * FROM modules ");
		$statement->execute();
		$statement->rowCount();
		return $statement->fetchAll(PDO::FETCH_OBJ);
	}

	public function getModuleById($moduleCode) {
		$statement = $this->dbcon->prepare("SELECT * FROM modules WHERE module_code = ?");
		$statement->bindValue(1, $moduleCode);
		$statement->execute();
		$statement->rowCount();
		return $statement->fetch(PDO::FETCH_OBJ);
	}

	public function getStudentEnrolledInfo($studentNumber) {
		$statement = $this->dbcon->prepare("SELECT DISTINCT(module_code), student_number FROM `enrollments` WHERE student_number = ?");
		$statement->bindValue(1, $studentNumber);
		$statement->execute();
		$statement->rowCount();
		return $statement->fetchAll(PDO::FETCH_OBJ);
	}

	public function getAllEnrollments() {
		$statement = $this->dbcon->prepare("SELECT DISTINCT module_code, student_number, COUNT(student_number) 'TOTAL_REGISTERED'
										FROM `enrollments`
										GROUP BY module_code");
		$statement->execute();
		$statement->rowCount();
		return $statement->fetchAll(PDO::FETCH_OBJ);
	}

	public function getStudentByEnrollement($module_code) {
		$statement = $this->dbcon->prepare("SELECT DISTINCT(student_number), module_code FROM `enrollments` WHERE module_code = ?");
		$statement->bindValue(1, $module_code);
		$statement->execute();
		$statement->rowCount();
		return $statement->fetchAll(PDO::FETCH_OBJ);
	}

	public function searchModules($searchTerm) {
		$searchTerm = "%".$searchTerm."%";
		$statement = $this->dbcon->prepare("SELECT * FROM `modules` WHERE module_code LIKE ? OR module_name LIKE ?");
		$statement->bindValue(1, $searchTerm);
		$statement->bindValue(2, $searchTerm);
		$statement->execute();
		if($statement->rowCount()) {
			return $statement->fetchAll(PDO::FETCH_OBJ);
		}
		else {
			return false;
		}
	}

}


?>