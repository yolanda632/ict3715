<?php
// require 'connect.php';

class Reports extends Database {
	private $dbcon = null;

	public function __construct() {
		$this->dbcon = parent::connect();
	}

	//query summary 1
	public function summary_report_query1() {
		$query = $this->dbcon->prepare("SELECT
							COUNT(id) 'TOTAL_COUNT',
							DAYNAME(exam_date) 'SUBMIT_DAY'
							FROM `examinations`
							WHERE NULLIF(exam_date,' ') IS NOT NULL
							GROUP BY SUBMIT_DAY");
		$query->execute();
		return $query->fetchAll(PDO::FETCH_OBJ);
	}

	//query summary 2
	public function summary_report_query2() {
		$query = $this->dbcon->prepare("SELECT DISTINCT module_code, 
							COUNT(module_code) 'TOTAL_STUDENTS'
							FROM `enrollments`
							GROUP BY module_code LIMIT 10");
		$query->execute();
		return $query->fetchAll(PDO::FETCH_OBJ);
	}

	//query trend report
	public function trend_report_query1() {
		$query = $this->dbcon->prepare("SELECT COUNT(module_code) AS 'TOTAL_MODULES',
								WEEKDAY(exam_date)+1 AS 'PER_WEEK'
								FROM `examinations`
								WHERE exam_date <> ''
								GROUP BY PER_WEEK ");
		$query->execute();
		return $query->fetchAll(PDO::FETCH_OBJ);
	}

	//query predictive report
	public function predictive_report_query() {
		$query = $this->dbcon->prepare("SELECT COUNT(student_number) 'TOTAL_SUBMISSIONS',
								MONTHNAME(exam_date) 'EXAMS_SUBMISSIONS'
								FROM `examinations`
								WHERE NULLIF(exam_date, '') IS NOT NULL
								GROUP BY EXAMS_SUBMISSIONS
								ORDER BY TOTAL_SUBMISSIONS ");
		$query->execute();
		return $query->fetchAll(PDO::FETCH_OBJ);
	}


}

?>