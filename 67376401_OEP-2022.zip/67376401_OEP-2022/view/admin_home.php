<?php
if(!$lecture->isAuthorized()) {
	open_page('?action=admin-login');
}

include('includes/header.php');

include('includes/menu.php');

$reportChart = $report->predictive_report_query();
$reportChart2 = $report->summary_report_query1();


?>
<style type="text/css">
	.card:hover {
		cursor: pointer;
	}
	.fa, p {
		color: #fff;
	}
</style>

<div class="container">
	
	<div class="row">
		<div class="col-md-12">
			
			<h4><i class="fa fa-dashboard" style="color:#777"></i> Admin Dashboard</h4>
			<hr>
			<div class="row">
				<div class="col-md-3">
					<div class="card bg-success">
						<div class="card-body" onclick="open_page('?action=show_students')">
							<h4 class="text-center">
								<i class="fa fa-users fa-4x"></i>
								<p>Students</p>
							</h4>
						</div>
					</div>
				</div>

				<div class="col-md-3">
					<div class="card bg-primary">
						<div class="card-body" onclick="open_page('?action=show_enrollments')">
							<h4 class="text-center">
								<i class="fa fa-graduation-cap fa-4x"></i>
								<p>Enrollments</p>
							</h4>
						</div>
					</div>
				</div>

				<div class="col-md-3">
					<div class="card bg-info">
						<div class="card-body" onclick="open_page('?action=list_exams')">
							<h4 class="text-center">
								<i class="fa fa-laptop fa-4x"></i>
								<p>Exam</p>
							</h4>
						</div>
					</div>
				</div>

				<div class="col-md-3">
					<div class="card bg-warning">
						<div class="card-body" onclick="open_page('?action=show_modules')">
							<h4 class="text-center">
								<i class="fa fa-book fa-4x"></i>
								<p>Modules</p>
							</h4>
						</div>
					</div>
				</div>
			</div>

		</div>
	</div>

	<div class="row">
		<div class="col-md-12 mt-5">
			<!-- My charts -->
			<canvas id="barChart" width="300" height="400"></canvas>
		</div>
		
	</div>

</div>

<?php include('includes/footer.php'); ?>

<script type="text/javascript">
	function open_page(url) {
		window.location.href = url;
	}

	function BarChart(items) {
		var daysNames = []; //create empty array to hold string names
		var totalStudents = []; //empty array to hold values
		for(item in items) {
			daysNames.push(items[item].EXAMS_SUBMISSIONS);
			totalStudents.push(items[item].TOTAL_SUBMISSIONS);
		}

		var ctx = document.getElementById("barChart").getContext('2d');
		//data
		var labels = daysNames;
		// var data = [66000, 41000, 33000];
		var myChart = new Chart(ctx, {
			type: 'bar',
			data: {
				labels: labels,
				datasets: [{
					label: 'Total Sumbission', //Name the series
					data: totalStudents,
					backgroundColor: [
						"#4BC0C0",
						"#4BC0C0",
						"#4BC0C0",
						"#4BC0C0",
						"#4BC0C0",
						"#4BC0C0",
						"#4BC0C0",
						"#4BC0C0",
						"#4BC0C0",
						"#4BC0C0",
						"#4BC0C0",
					],
					borderColor: [ //adding custom color
						/*"#FF6384",
			            "#4BC0C0",
			            "#FFCE56",
			            "#36A2EB",
			            "#8AC054",
			            "#967ADA",
			            "#E7E9ED"*/
					],
					borderWidth: 0 //specify bar border
				}]
			},
			options: {
				title: {
		            display: true,
		            text: 'Predictive Report'
		        },
				responsive: true, //Instruct ChartJs to respond nicely
				maintainAspectRatio: false, //Add to prevent default behaviour of full width/height
			}
		});
	}
	var itemsBarArr = <?php echo json_encode($reportChart); ?>;
	BarChart(itemsBarArr); //call function do display Bar Chart


	

</script>

