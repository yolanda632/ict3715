<?php

include('includes/header.php');

include('includes/menu.php');


?>

<div class="container">
	<h3>Examination is complete</h3>
	<hr>

	<div class="card">
		<div class="card-body">
			<h1 class="text-success">THANK YOU</h1>
			<p class="text-secondary">Thank You for your submission! Your file is uploaded.</p>
			<div>
				<a href="?action=welcome" class="btn btn-success">Complete</a>
			</div>
		</div>
	</div>

</div>