<?php

include('includes/header.php'); 
include('includes/menu.php'); 

// $report = new Reports();
$reportChart = $report->predictive_report_query();
$reportChart2 = $report->summary_report_query1();

?>

<style type="text/css">
	/*.tables {
		width: 600px;
		border-collapse: collapse;
		border-color: #ddd;
	}
	.tables tr td {
		padding: 5px 10px;
		border-color: #ddd;
		color: #444;
	}
	.tables tr:nth-child(even) {
		background-color: #f0f1f5;
	}*/
	/*.table thead th {
		background-color: #015c92;
		color: #fff;
	}*/
</style>

<div class="container">

	<div class="row">
		<div class="col-md-6 mt-5">
			<!-- My charts -->
			<canvas id="barChart" width="300" height="400"></canvas>
		</div>
		<div class="col-md-6 mt-5">
			<!-- My charts -->
			<canvas id="pieChart" width="300" height="400"></canvas>
		</div>
	</div>
		<hr>

	<div class="row">
		<div class="col-md-6">
			<table border="0" class="table table-striped table-bordered">
				<h4>Summary Report</h4>
				<thead class="bg-info text-light"><th>TOTAL NUMBER OF STUDENTS</th></thead>
				<?php foreach($report->summary_report_query2() as $row): ?>
					<tr>
						<!-- <td><?php #echo $row->MODULES; ?></td> -->
						<td><?php echo $row->TOTAL_STUDENTS; ?></td>
					</tr>
				<?php endforeach; ?>
			</table>
		</div>
		<div class="col-md-6">
			<table border="0" class="table table-striped table-bordered">
				<h4>Trend Report</h4>
				<thead class="bg-info text-light"><th>TOTAL MODULES</th>
					<th>PER WEEK</th></thead>
				<?php foreach($report->trend_report_query1() as $row): ?>
					<tr>
						<td><?php echo $row->TOTAL_MODULES; ?></td>
						<td><?php echo $row->PER_WEEK; ?></td>
					</tr>
				<?php endforeach; ?>
			</table>
		</div>
	</div>

	<div class="row">
		<!-- <div class="col-md-6">
			<table border="0" class="table table-striped table-bordered">
				<h4>Summary Report</h4>
				<thead class="bg-info text-light"><th>NUMBER OF STUDENTS</th><th>DAYS</th></thead>
				<?php #foreach($report->summary_report_query1() as $row): ?>
					<tr>
						<td><?php #echo $row->TOTAL_COUNT; ?></td>
						<td><?php #echo $row->SUBMIT_DAY; ?></td>
					</tr>
				<?php #endforeach; ?>
			</table>
		</div> -->
		<!-- <div class="col-md-6">
			<table border="0" class="table table-striped table-bordered">
				<h4>Predictive Report</h4>
				<thead class="bg-info text-light"><th>EXAMS SUBMISSIONS</th><th>TOTAL SUBMISSIONS</th></thead>
				<?php #foreach($report->predictive_report_query() as $row): ?>
					<tr>
						<td><?php #echo $row->EXAMS_SUBMISSIONS; ?></td>
						<td><?php #echo $row->TOTAL_SUBMISSIONS; ?></td>
					</tr>
				<?php #endforeach;?>
			</table>
		</div> -->

	</div>
</div>

<?php include('includes/footer.php'); ?>

<script type="text/javascript">
	function BarChart(items) {
		var daysNames = []; //create empty array to hold string names
		var totalStudents = []; //empty array to hold values
		for(item in items) {
			daysNames.push(items[item].EXAMS_SUBMISSIONS);
			totalStudents.push(items[item].TOTAL_SUBMISSIONS);
		}

		var ctx = document.getElementById("barChart").getContext('2d');
		//data
		var labels = daysNames;
		// var data = [66000, 41000, 33000];
		var myChart = new Chart(ctx, {
			type: 'bar',
			data: {
				labels: labels,
				datasets: [{
					label: 'Monthly Sumbission', //Name the series
					data: totalStudents,
					fill: false,
			        backgroundColor: ["#967ADA","#967ADA","#967ADA","#967ADA","#967ADA","#967ADA","#967ADA","#967ADA",
			        "#967ADA","#967ADA","#967ADA"],
			        borderColor: ["#967ADA"],
			        borderWidth: 1
				}]
			},
			options: {
				title: {
		            display: true,
		            text: 'Future Predictions - Predictive Report'
		        },
				responsive: true, //Instruct ChartJs to respond nicely
				maintainAspectRatio: false, //Add to prevent default behaviour of full width/height
			}
		});
	}
	var itemsBarArr = <?php echo json_encode($reportChart); ?>;
	BarChart(itemsBarArr); //call function do display Bar Chart


	function PieChart(items) {
		var submitDay = []; //create empty array to hold string names
		var totalCount = []; //empty array to hold values
		for(item in items) {
			submitDay.push(items[item].SUBMIT_DAY);
			totalCount.push(items[item].TOTAL_COUNT);
		}
		var chartDiv = document.getElementById("pieChart").getContext('2d');
		var myChart = new Chart(chartDiv, {
		    type: 'pie',
		    data: {
		        labels: submitDay,//["Pending", "InProgress", "OnHold", "Complete", "Cancelled"],
		        datasets: [
		        {
		            data: totalCount,//[21,39, 10, 14,16],
		            backgroundColor: [
		            "#FF6384",
		            "#4BC0C0",
		            "#FFCE56",
		            "#36A2EB",
		            "#FF6611",
		            "#8AC054",
		            "#967ADA",
		            // "#E7E9ED",
		            '#5f51b5',
		            "#737373",
		            "#373234",
		            ]
		        }]
		    },
		    options: {
		        title: {
		            display: true,
		            text: 'Weekly Summary - Sumbission Report'
		        },
				responsive: true,
				maintainAspectRatio: false,
		    }
		});
	}
	var itemsPieArr = <?php echo json_encode($reportChart2); ?>;
	PieChart(itemsPieArr); //call the function to display a pie chart

</script>