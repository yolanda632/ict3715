<?php

include('includes/header.php');

include('includes/menu.php');

?>

<div class="container ">
	<div class="row">
		<div class="col-md-10">

			<div class="card">
				<div class="card-body">
					<p class="text-muted">Select checkbox below to declare and continue</p>
					<form action="" method="GET" enctype="" id="formSubmit">
						<input type="hidden" name="action" value="begin_exam">
						<input type="hidden" name="exam_code" value="<?php echo $_REQUEST['exam_code']; ?>">
						<label>
							<input type="checkbox" id="declare" name="declare" value="on">
							I declare that i have been honest.
						</label>
						<div class="form-group mt-3">
							<a href="?action=get_exam&exam_code=<?php echo $_REQUEST['exam_code'] ?>" class="btn btn-primary"><i class="fa fa-arrow-left"></i> Back</a>
							<button type="button" class="btn btn-success" id="startExam" name="action" value="begin_exam">Start Exam</button>
						</div>
					</form>
				</div>
			</div>

		</div>
	</div>
</div>

<?php include('includes/footer.php'); ?>

<script type="text/javascript">
	$(function() {
		$('#startExam').click(function() {
			if($('#declare').is(':checked')) {
				$('#formSubmit').submit();
			}
			else {
				alert('Please select to declare to start examination');
			}
		});
	});
</script>