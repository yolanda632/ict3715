<?php

if(!$student->isAuthorized()) {
	open_page('?action=login');
	exit();
}

include('includes/header.php');

include('includes/menu.php');


if(!empty($_SESSION['student']['email'])) {
	$studentID = explode('@', $_SESSION['student']['email'])[0];
	
}

if(isset($_REQUEST['my_exams'])) {
	$allExams = $exam->getCurrentExams($studentID);
}
else {
	$allModules = $module->getStudentEnrolledInfo($studentID);
}

$profile = $student->getStudentByID($studentID);

?>

<div class="container">
	<div class="row">
		
		<div class="col-md-12 text-center mt-3">
			<h3>Hi, <?php echo $profile->student_name.' '.$profile->student_surname; ?></h3>
			<h1>Welcome to online exam portal 2022</h1>
			<a href="?action=welcome&my_exams=view" class="btn btn-primary mt-3"><i class="fa fa-pencil"></i> Show myExams</a>
			<a href="?action=welcome&my_modules=view" class="btn btn-info mt-3"><i class="fa fa-book"></i> Show myModules</a>
		</div>
<?php #echo $_SESSION['student']['email']; ?>
	</div>

	<div class="row mt-5 mb-4 bg-flush text-center" style="height: 350px; max-height: 600px; overflow: auto; box-shadow: 1px 2px 4px rgba(0,0,0,0.5)">

		<?php if(!isset($_REQUEST['my_exams'])) { ?>

		<div class="col-md-12 mt-3 ">
			<h4 class="text-dark">My Modules Enrolled <i class="fa fa-book"></i></h4><hr>
		</div>
		<?php if($allModules != false) : ?>
		<?php foreach($allModules as $row): ?>
		<?php $data = $module->getModuleById($row->module_code); ?>
		<div class="col-md-3 mt-2 mb-4">
			<div class="card" style="box-shadow: 1px 2px 4px rgba(0,0,0,0.5)">
				<div class="card-body bg-light">
					<h4 class="card-title"><?php echo $row->module_code; ?></h4>
					<p class="card-text mb-4"><?php echo $data->module_name; ?></p>
					<!-- <a href="<?php echo $row->module_code; ?>" class="btn btn-dark">View</a> -->
				</div>
			</div>
		</div>
		<?php endforeach; ?>
		<?php else: ?>
			<div class="col-md-10 mx-auto"><div class="alert alert-danger text-center">You did not enrol for any module(s).</div></div>
		<?php endif; ?>

		<?php } else { ?>

			<div class="col-md-12 mt-3 ">
				<h4 class="text-dark">My Current Exams <i class="fa fa-pencil"></i></h4><hr>
			</div>
			<?php
			if($allExams != false) {
				foreach($allExams as $rec): 
				$modinfo = $module->getModuleById($rec->module_code);
				$toggleClass = ($exam->isExamWritten($studentID, $rec->module_code)==true) ? 'disabled' : '';
			?>
			<div class="col-md-3 mt-2 mb-4">
				<div class="card" style="box-shadow: 1px 2px 4px rgba(0,0,0,0.5)">
					<div class="card-body">
						<h4 class="card-title"><?php echo $rec->module_code; ?></h4>
						<p class="card-text mt-2"><?php echo $modinfo->module_name; ?></p>
						<a href="?action=get_exam&exam_code=<?php echo $rec->module_code; ?>" class="btn btn-primary <?php echo $toggleClass; ?>">View</a>
					</div>
				</div>
			</div>
			<?php 
				endforeach;
			} else {
				echo "<div class='col-md-10 mx-auto'><div class='alert alert-danger text-center'>You have no examinations currently.</div></div>";
			}
			?>

		<?php } ?>

	</div>

</div>

<?php include('includes/footer.php'); ?>
