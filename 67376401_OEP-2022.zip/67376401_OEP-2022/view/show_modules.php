<?php

	include('includes/header.php');
	include('includes/menu.php');

	$module = new Module();
	$allModules = $module->getModules();

?>

<div class="container">
	<h4 class="">Modules 
		<button type="button" class="btn btn-primary float-right" name="searchBtn" id="searchBtn"><i class="fa fa-search"></i> Search</button style="width: 350px;">
		<input type="search" class="form-control float-right" name="search_text" id="searchText" placeholder="filter modules" style="width: 350px;">
	</h4>
	<hr>

	<table class="table table-bordered table-striped">
		<thead>
			<th>Module Code</th><th>Module Name</th><th>Action</th>
		</thead>
		<tbody id="tbl_results">
			<?php foreach($allModules as $row): ?>
			<tr>
				<td><?php echo $row->module_code; ?></td>
				<td><?php echo $row->module_name; ?></td>
				<td><a href="?action=show_enrollments&moduleCode=<?php echo $row->module_code; ?>" class="btn btn-primary">Show Enrolled</a></td>
			</tr>
			<?php endforeach; ?>
		</tbody>
	</table>

</div>

<?php include('includes/footer.php'); ?>

<script type="text/javascript">
	
	$(function() {
		$('#searchBtn').click(function() {
			filterModules();
		});

		$('#searchText').on('keyup', function() {
			if($('#searchText').val().length >= 2) {
				filterModules();
			}
		});
	});


	function filterModules() {
		var searchText = $('#searchText').val();
		$.get("index.php", {"action":"filter_modules", "search_text":searchText}, function(responseData) {
			if(responseData != "false") {
				let table_data = "";
				var data = JSON.parse(responseData);
				data.forEach(function(row, i) {
					table_data += "<tr>"+
					"<td>"+row.module_code+"</td>"+
					"<td>"+row.module_name+"</td>"+
					"<td>"+
					"<a href='?action=show_enrollments&moduleCode="+row.module_code+"' class='btn btn-primary'>Show Enrolled</a>"+
					"</td>"+
					"</tr>";
					$('#tbl_results').html(table_data);
				});
			}
			else {
				$('#tbl_results').html("<tr><td colspan='3'><div class='alert alert-info'>No matching record found!</div></td></tr>");
			}
		});
	}

</script>