<?php include("includes/header.php"); ?>
	<style type="text/css">
		.container-item {
			width: 500px;
			background-color: #fff;
			box-shadow: 1px 2px 4px rgba(0, 0, 0, 0.5);
			padding: 20px;
			font-family: arial;
			margin: 80px auto;
		}
		.controls {
			width: 100%;
			padding: 10px 0;
			margin: 15px 0;
			text-indent: 5px;
			border: none;
			border-bottom: thin solid #5aa2e0;
			outline: 0;
		}
		.controls:focus {
			border-bottom: 2px solid #5aa2e0;
		}
		input::-webkit-outer-spin-button,
		input::-webkit-inner-spin-button {
			-webkit-appearance: none;
			margin: 0;
		}
		input[type=number] {
			-moz-appearance: textfield;
		}
		.loginBtn {
			width: 100px;
			padding: 10px;
			background-color: #5aa2e0;
			color: #fff;
			border: none;
			border-radius: 5px;
			cursor: pointer;
			margin: 10px 0;
			font-weight: bold;
		}
		.loginBtn:hover {
			background-color: #6cb6f5;
		}
		.heading {
			font-size: 1.8em;
			color: #5aa2e0;
			text-align: center;
			margin: 10px 0;
		}
		.links {
			color: #999;
		}
		.links a {
			text-decoration: none;
			color: #5aa2e0;
		}
	</style>

	

	<div class="container-item">
		<div class="heading"><i class=""></i> STUDENT LOGIN</div>
		<form action="" method="POST">
			<div>
				<input type="email" class="controls" name="email" placeholder="Enter email address">
			</div>
			<div>
				<input type="password" class="controls" name="password" placeholder="Enter surname">
			</div>
			<div align="right">
				<button type="submit" class="loginBtn" name="action" value="student-login">Login</button>
			</div>
		</form>
		<br>
		<div class="links"><center>Login as <a href="?action=admin-login">Lecturer</a></center></div>
	</div>
	<div class="col-md-5 mx-auto">
		<?php echo (!empty($error)) ? $error : ''; ?>
	</div>
</body>
</html>