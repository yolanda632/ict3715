<?php
if(!$student->isAuthorized()) {
	open_page('?action=login');
	exit();
}

include('includes/header.php');

include('includes/menu.php');

if(!empty($_SESSION['student']['email'])) {
	$studentID = explode('@', $_SESSION['student']['email'])[0];
	// $studentID = '44974825';
}

if(isset($_REQUEST['exam_code'])) {
	$exam_info = $exam->getExamInfo($_REQUEST['exam_code']);
	$data = $module->getModuleById($exam_info->module_code);
}

//calculate exam duration, with date difference between two dates
$date1 = new DateTime($exam_info->start_time);
$date2 = new DateTime($exam_info->completion_time);

$interval = date_diff($date1, $date2);
$examDuration = $interval->format("%Hhr-%imin");

//check exam date to enable button
if($exam_info->exam_date == date('Y-m-d')) {
	$toggleBtn = "";
}
else {
	$toggleBtn = "disabled";
}

?>

<div class="container">
	<h3>My Examination Information</h3>
	<hr>
	<div class="row">
		<div class="col-md-10 mx-auto">
			
			<table class="table table-bordered table-striped">
				<tr>
					<td>Module Code:</td><td><?php echo $exam_info->module_code; ?></td>
				</tr>
				<tr>
					<td>Module Name:</td><td><?php echo $data->module_name; ?></td>
				</tr>
				<tr>
					<td>Exam Type:</td><td><?php echo ucfirst($exam_info->exam_type); ?></td>
				</tr>
				<tr>
					<td>Exam Date:</td><td><?php echo date('D, d-M-Y', strtotime($exam_info->exam_date)); ?></td>
				</tr>
				<tr>
					<td>Start Time:</td><td><?php echo date('H:i A', strtotime($exam_info->start_time)); ?></td>
				</tr>
				<tr>
					<td>End Time:</td><td><?php echo date('H:i A', strtotime($exam_info->completion_time)); ?></td>
				</tr>
				<tr>
					<td>Exam Duration:</td><td><?php echo $examDuration; ?></td>
				</tr>
			</table>
			<div class="text-center">
				<a href="?action=welcome&my_exams=view" class="btn btn-primary"><i class="fa fa-arrow-left"></i> Back </a>
				<a href="?action=student_declare&exam_code=<?php echo $exam_info->module_code; ?>" id="proceedBtn" class="btn btn-success ">Continue <i class="fa fa-arrow-right"></i></a>
			</div>
		</div>
	</div>

</div>

<?php include("includes/footer.php"); ?>

<script type="text/javascript">
	$(function() {
		var toggleBtn = '<?php echo $toggleBtn; ?>';
		$('#proceedBtn').addClass(toggleBtn);
	});
</script>