<?php

	include('includes/header.php');
	include('includes/menu.php');

	$student = new Student();
	$allStudents = $student->getAllStudent();

?>

<div class="container">
	<h4 class="">All Students <span class="badge badge-info"><?php echo count($allStudents); ?></span>
		<button type="button" class="btn btn-primary float-right" name="action" value="filter_student" id="searchBtn"><i class="fa fa-search"></i> Search</button style="width: 350px;">
		<input type="search" class="form-control float-right" name="searchInput" id="searchInput" placeholder="search for students" style="width: 350px;">
	</h4>
	<hr>

	<table class="table table-bordered table-striped">
		<thead>
			<th>Student Number</th><th>Firstname</th><th>Lastname</th><th>Email</th>
		</thead>
		<tbody id="result_table">
			<?php foreach($allStudents as $row) : ?>
			<tr>
				<td><?php echo $row->student_number; ?></td>
				<td><?php echo $row->student_name; ?></td>
				<td><?php echo $row->student_surname; ?></td>
				<td><?php echo $row->student_email; ?></td>
				<!-- <td><a href="" class="btn btn-warning">Edit</a></td> -->
			</tr>
			<?php endforeach; ?>
		</tbody>
	</table>

</div>

<?php include('includes/footer.php'); ?>

<script type="text/javascript">
	$(function() {
		$('#searchBtn').click(function() {

			var searchValue = $('#searchInput').val();
			$.get("index.php", {"action":"filter_student", "search_value":searchValue}, function(reponseData) {
				
				if(reponseData != "false") {
					var tbl_data = "";
					//format data into JSON array object
					var json_data = JSON.parse(reponseData);
					//loop over returned result array object
					json_data.forEach(function(row, i) {
						tbl_data += "<tr>";
						tbl_data += "<td>"+row.student_number+"</td>";
						tbl_data += "<td>"+row.student_name+"</td>";
						tbl_data += "<td>"+row.student_surname+"</td>";
						tbl_data += "<td>"+row.student_email+"</td>";
						tbl_data += "</tr>";
					});
					$('#result_table').html(tbl_data); //print results to html
				}
				else { //else print error message
					$('#result_table').html("<tr><td colspan='4'><div class='alert alert-info'>No matching record found!</div></td></tr>");
				}

			});

		});
	});
</script>