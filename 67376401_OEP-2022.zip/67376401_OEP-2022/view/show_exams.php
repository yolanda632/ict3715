<?php

	include('includes/header.php');
	include('includes/menu.php');

	$exam = new Exams();
	$module = new Module();

	if(isset($_REQUEST['edit'])) {
		$examInfo = $exam->getExamByID($_REQUEST['edit']);
	}
	else if(isset($_REQUEST['info'])) {
		$modInfo = $exam->getExamByID($_REQUEST['info']);
		$modDesc = $module->getModuleById($modInfo->module_code); 
	}

	$allModules = $module->getModules();
	$activeExams = $exam->getAllExams();

?>

<div class="container">
	<h4 class="">List All Examinations 
		<a href="?action=addnew_exam" class="btn btn-success float-right"><i class="fa fa-plus"></i> Add Exam</a>
		<a href="?action=home" class="btn btn-primary float-right mr-2"><i class="fa fa-home"></i> Home</a>
	</h4>
	<hr>

	<?php if(!isset($_REQUEST['edit']) && !isset($_REQUEST['info'])) { ?>

	<input type="search" class="form-control float-left" name="searchText" id="searchText" placeholder="search by module code" style="width: 350px;">
	<button type="button" class="btn btn-primary mb-3" name="searchBtn" id="searchBtn"><i class="fa fa-search"></i> Search</button style="width: 350px;">

	<table class="table table-bordered">
		<thead>
			<th>ExamID</th><th>Module Code</th><th>Exam Date</th><th>Exam Type</th><th>Action</th>
		</thead>
		<tbody id="tbl_results">
			<?php foreach($activeExams as $row): ?>
			<tr>
				<td><?php echo $row->module_code; ?></td>
				<td><?php echo $row->exam_date; ?></td>
				<td><?php echo date('H:i A', strtotime($row->start_time)); ?></td>
				<td><?php echo $row->exam_type; ?></td>
				<td>
					<a href="?action=list_exams&edit=<?php echo $row->id; ?>" class="btn btn-warning">Edit</a>
					<a href="?action=list_exams&info=<?php echo $row->id; ?>" class="btn btn-primary">Show info</a>
				</td>
			</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
	<?php } ?>
	<?php if(isset($_REQUEST['edit'])) { ?>
		<div class="card">
			<div class="card-body">
				<h4 class="">Update Exam information <?php echo $examInfo->module_code; ?></h4>
				<form action="" method="POST" enctype="multipart/form-data">
					<div class="form-group">
						<input type="hidden" name="examID" value="<?php echo $examInfo->id; ?>">
						<select class="form-control" name="moduleCode">
							<option value="">Select Module</option>
							<?php foreach($allModules as $mod): ?>
								<option value="<?php $mod->module_code ?>" <?php echo ($mod->module_code == $examInfo->module_code) ? 'selected' : ''; ?> >
									<?php echo $mod->module_code.' - '.$mod->module_name; ?>
								</option>
							<?php endforeach; ?>
						</select>
					</div>
					<div class="form-group">
						<input type="date" class="form-control" name="examDate" value="<?php echo $examInfo->exam_date; ?>">
					</div>
					<div class="form-group">
						<input type="time" class="form-control" name="examTimeStart" value="<?php echo $examInfo->start_time; ?>">
					</div>
					<div class="form-group">
						<input type="time" class="form-control" name="examTimeEnd" value="<?php echo $examInfo->completion_time; ?>">
					</div>
					<div class="form-group">
						<select class="form-control" name="examType">
							<option value="<?php echo $examInfo->exam_type; ?>"><?php echo $examInfo->exam_type; ?></option>
						</select>
					</div>
					<div class="form-group">
						<input type="file" class="form-control" name="exam_paper">
						<div class="text-danger"><strong>Uploaded File: <?php echo $examInfo->upload; ?></strong></div>
					</div>
					<div class="form-group">
						<button type="submit" class="btn btn-primary" name="action" value="update-exam">Update</button>
					</div>
				</form>
			</div>
		</div>
	<?php } ?>

	<?php if(isset($_REQUEST['info'])) { ?>
		<a href="?action=list_exams" class="btn btn-info mb-2"><i class="fa fa-arrow-left"></i> Back</a>
		<table class="table table-bordered table-striped">
			<tbody class="">
				<tr>
					<td>Module Code</td><td><?php echo $modInfo->module_code; ?></td>
				</tr>
				<tr>
					<td>Module Name</td><td><?php echo $modDesc->module_name; ?></td>
				</tr>
				<tr>
					<td>Exam Type</td><td><?php echo $modInfo->exam_type; ?></td>
				</tr>
				<tr>
					<td>Exam Date</td><td><?php echo $modInfo->exam_date; ?></td>
				</tr>
				<tr>
					<td>Start Time</td><td><?php echo $modInfo->start_time; ?></td>
				</tr>
				<tr>
					<td>Completion Time</td><td><?php echo $modInfo->completion_time; ?></td>
				</tr>
				<tr>
					<td>Exam File Document</td><td><?php echo $modInfo->upload; ?></td>
				</tr>
			</tbody>
		</table>
	<?php } ?>
</div>

<?php include('includes/footer.php'); ?>

<script type="text/javascript">
	
	$(function() {
		$('#searchBtn').click(function() {
			var searchText = $('#searchText').val();
			$.get("index.php", {"action":"filter_exams", "search_text":searchText}, function(responseData) {
				if(responseData != "false") {
					let table_data = "";
					var data = JSON.parse(responseData);
					data.forEach(function(row, i) {
						table_data += "<tr>"+
						"<td>"+row.module_code+"</td>"+
						"<td>"+row.exam_date+"</td>"+
						"<td>"+row.start_time+"</td>"+
						"<td>"+row.exam_type+"</td>"+
						"<td>"+
						"<a href='?action=list_exams&edit="+row.id+"' class='btn btn-warning'>Edit</a>"+
						"<a href='?action=list_exams&info="+row.id+"' class='btn btn-primary'>Show info</a>"+
						"</td>"+
						"</tr>";
						$('#tbl_results').html(table_data);
					});
				}
				else {
					$('#tbl_results').html("<tr><td colspan='5'><div class='alert alert-info'>No matching record found!</div></td></tr>");
				}
			});
		});
	});

</script>