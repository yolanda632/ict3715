<?php

	include('includes/header.php');
	include('includes/menu.php');

	$module = new Module();
	$modules = $module->getModules();

?>

<div class="container">
	<h4 class="">Create New Examination 
		<a href="?action=list_exams" class="btn btn-primary float-right" name="" id=""><i class="fa fa-arrow-left"></i> Show Exams</a>
	</h4>
	<hr>
	<div class="row">
		<div class="col-md- mx-auto">
			<div class="card mb-3">
				<div class="card-body">
					<form action="" method="POST" enctype="multipart/form-data">
						<div class="form-group">
							<select class="form-control" name="moduleCode">
								<option value="">Select Module</option>
								<?php foreach($modules as $row): ?>
									<option value="<?php echo $row->module_code; ?>"><?php echo $row->module_code.' - '.$row->module_name; ?></option>
								<?php endforeach; ?>
							</select>
						</div>
						<div class="form-group">
							<select class="form-control" name="examType">
								<option value="">Select Exam Type</option>
								<!-- <option value="mcq">MCQ</option> -->
								<!-- <option value="fill-in">Fill-In</option> -->
								<option value="upload">File Upload</option>
							</select>
						</div>
						<div class="form-group">
							<label>Exam Date:</label><br>
							<input type="date" class="form-control" name="examDate" placeholder="">
						</div>
						<div class="form-group">
							<label>Start Time:</label><br>
							<input type="time" class="form-control" name="examTimeStart" placeholder="00:00">
						</div>
						<div class="form-group">
							<label>End Time:</label><br>
							<input type="time" class="form-control" name="examTimeEnd" placeholder="00:00">
						</div>
						<div class="form-group">
							<input type="file" class="form-control" name="exam_paper">
						</div>
						<div class="form-group">
							<button type="submit" class="btn btn-success" name="action" value="upload-exam">Create New</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>

</div>