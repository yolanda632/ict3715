<?php

	include('includes/header.php');
	include('includes/menu.php');

	$module = new Module();
	$student = new Student();

	if(isset($_REQUEST['moduleCode'])) {
		$allEnrolled = $module->getStudentByEnrollement($_REQUEST['moduleCode']);
		$modInfo = $module->getModuleById($_REQUEST['moduleCode']);
	}
	else {
		$enrol = $module->getAllEnrollments();
	}


?>

<div class="container">
	<h4 class="">Enrollements</h4>
	<hr>
	<?php if(!isset($_REQUEST['moduleCode'])) { ?>
	<table class="table table-bordered table-striped">
		<thead>
			<th>Module Code</th><th>Module Name</th><th>Total Enrolled</th><th>Action</th>
		</thead>
		<tbody>
			<?php foreach($enrol as $row): ?>
			<?php $rec = $module->getModuleById($row->module_code); ?>
			<tr>
				<td><?php echo $row->module_code; ?></td>
				<td><?php echo $rec->module_name; ?></td>
				<td><?php echo $row->TOTAL_REGISTERED; ?></td>
				<td><a href="?action=show_enrollments&moduleCode=<?php echo $row->module_code; ?>" class="btn btn-sm btn-primary">View</a></td>
			</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
	<?php } else { ?>
		<div>Total Students Registered <span class="badge badge-primary"><?php echo count($allEnrolled); ?></span></div>
		<a href="?action=show_enrollments" class="btn btn-sm btn-info float-right mb-2"><i class="fa fa-arrow-left"></i> Back</a>
		<center><caption><?php echo $modInfo->module_code.' - '.$modInfo->module_name; ?></caption></center>
		<table class="table table-bordered table-striped">
			<thead class="table-primary">
				<th>Student Number</th><th>Firstname</th><th>Lastname</th><th>Email</th>
			</thead>
			<?php foreach($allEnrolled as $user): ?>
				<?php $stud = $student->getStudentByID($user->student_number); ?>
				<tr>
					<td><?php echo $stud->student_number; ?></td>
					<td><?php echo $stud->student_name; ?></td>
					<td><?php echo $stud->student_surname; ?></td>
					<td><?php echo $stud->student_email; ?></td>
				</tr>
			<?php endforeach; ?>
		</table>
	<?php } ?>

</div>