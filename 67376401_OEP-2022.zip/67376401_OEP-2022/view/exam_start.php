<?php

if(!$student->isAuthorized()) {
	open_page('?action=login');
	exit();
}

include('includes/header.php');

include('includes/menu.php');

if(!empty($_SESSION['student']['email'])) {
	$studentID = explode('@', $_SESSION['student']['email'])[0];
	// $studentID = '44974825';
}
if(isset($_REQUEST['exam_code'])) {
	$dirpath = "exams/examinations/";
	$exam_info = $exam->getExamInfo($_REQUEST['exam_code']);
	$data = $module->getModuleById($exam_info->module_code);

	$studInfo = $student->getStudentByID($studentID);
	//get time interval difference between two times
	$date1 = new DateTime($exam_info->start_time);
	$date2 = new DateTime($exam_info->completion_time);
	//calculate time difference intervals
	$interval = date_diff($date1, $date2);
	$hours = $interval->format("%H"); //extract hours
	$minutes = $interval->format("%i"); //extract minutes

} else {
	$hours = 0;
	$minutes = 0;
}

?>

<div class="container">
	<h3>Examination in progress 
		<span id="count_time" class="float-right badge badge-pill badge-primary">Time left: 0:0:0</span>
		<!-- <span class="float-right badge badge-pill badge-secondary">Questions: 1</span> -->
	</h3>
	<hr>
	<div class="row">
		<div class="col-md-8 mx-auto">
			<div id="notify"></div>
			<div class="card"> 
				<div class="card-body">
					<p class="text-primary">
						<?php echo $exam_info->upload; ?>
						<a href="?action=download-exam&filename=<?php echo $exam_info->upload; ?>" class="btn btn-sm btn-primary"><i class="fa fa-download"></i> Download</a>
					</p>
					<form action="" method="POST" enctype="multipart/form-data">
						<input type="hidden" name="studentID" value="<?php echo $studentID; ?>">
						<input type="hidden" name="module_code" value="<?php echo $_REQUEST['exam_code']; ?>">
						<input type="hidden" name="exam_date" value="<?php echo $exam_info->exam_date; ?>">
						<div class="form-group">
							<input type="file" class="form-control mt-3" id="doc_upload" name="exam_paper">
							<div class="text-muted">Only PDF files allowed for file uploads.</div>
						</div>
						<div class="form-group">
							<button type="submit" class="btn btn-success btn-upload" name="action" value="exam_submit">Upload</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
	var hours = <?php echo $hours; ?>;
	var minutes = <?php echo $minutes; ?>;
	var seconds = 60;

	var countTimer = function() {
		seconds--;
		if(seconds == -1) {
			seconds = 59;
			if(minutes == 0) {
				if(hours != 0) {
					hours--;
					minutes = 59;
				}
				if(hours == 0 && minutes == 0) {
					minutes = 0;
				}
			}
			else {
				minutes--;
			}
		}

		$('#count_time').html('Time left: '+hours +':'+ minutes +':'+ seconds);
		stopTimer(hours, minutes, seconds); //check for counter value every iterate
	}

	var timer = setInterval(countTimer, 1200);

	function stopTimer(hrs, mins, secs) {
		if(hrs == 0 && mins == 0 && secs == 0) {
			clearInterval(timer);
			$('#count_time').html('Time left: 0:0:0');
			$('#count_time').removeClass('badge-primary').addClass('badge-danger');
			$('#doc_upload').attr('disabled', true);
			$('.btn-upload').attr('disabled', true);
			$("#notify").html("<i class='fa fa-ban'></i> Examination session has ended!.");
			return false;
			// alert('Examination session has ended');
			/*setTimeout(function() {
				window.open('?action=welcome','_self');
			}, 500);*/
		}
		if(hrs <=0 && mins <= 15) {
			$("#notify").html("<i class='fa fa-exclamation-circle'></i> You have less than 15 minutes before exam time expires!!").addClass('alert alert-info');
		}
		if(hrs <=0 && mins <= 14) {
			$("#notify").html("<i class='fa fa-exclamation-circle'></i> You have less than 10 minutes before exam time expires!!").removeClass('alert-info').addClass('alert alert-warning');
		}
		if(hrs <=0 && mins <= 13) {
			$("#notify").html("<i class='fa fa-exclamation-circle'></i> You have less than 5 minutes before exam time expires!!").removeClass('alert-warning').addClass('alert alert-danger');
		}
	}
</script>



<script type="text/javascript">

// Set the date we're counting down to
// var countDownDate = new Date("Sep 16, 2021 14:39:00").getTime();
/*var countDownDate = "<?php #echo $examtime ?>";

var myDate = Date.parse(countDownDate);

// Update the count down every 1 second
var x = setInterval(function() {

  // Get today's date and time
  var now = new Date().getTime();
    
  // Find the distance between now and the count down date
  var timediff = myDate - now;
    
  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(timediff / (1000 * 60 * 60 * 24));
  var hours = Math.floor((timediff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((timediff % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((timediff % (1000 * 60)) / 1000);
    
  // Output the result in an element with id="demo"
  document.getElementById("timer").innerHTML = "Time Left: " + hours + ":"
  + minutes + ":" + seconds;
    
  // If the count down is over, write some text 
  if(hours <=0 && minutes <= 10 && minutes > 5){
    document.getElementById("warning").innerHTML = "You have less than 10 minutes, Submit before time gets EXPIRED!";
  }else if(hours <=0 && minutes <= 5 && minutes > 3){
    document.getElementById("warning").innerHTML = "You have less than 5 minutes, Submit before time gets EXPIRED!";
  }else if(hours <=0 && minutes <= 3){
    document.getElementById("warning").innerHTML = "You have less than 3 minutes, Submit NOW before time gets EXPIRED!";
  }
  if (timediff < 0) {
    clearInterval(x);
    document.getElementById("timer").innerHTML = "EXPIRED";
    document.getElementById("upload").style.display = "none";
  }
}, 1000);*/
</script>