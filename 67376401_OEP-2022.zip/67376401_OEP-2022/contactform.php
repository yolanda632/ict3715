<?php

//Web Contact form
$_REQUEST['submit'] = "true";

if (isset($_REQUEST['submit'])) {
	$name = "Lucky Molefe";
	$telNum = "0813881759";
	$email = "test@test.com";
	$subject = "test subject";
	$message = "testing message for email"; #htmlentities(stripslashes(strip_tags(trim($_POST['message']))));

	if(!empty($name) || !empty($telNum) || !empty($subject) || !empty($message)) {
		if(!empty($email)) {
			if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
				echo "Invalid email address!";
				exit();
			}
		}
		if(!is_numeric($telNum)) {
			echo "Invalid cellphone number!";
			exit();
		}

		if(file_exists("PHPMailer/PHPMailerAutoload.php")) {
			require_once('PHPMailer/PHPMailerAutoload.php');
			$mail = new PHPMailer();
		}

		//Mail Server Connection Settings
		$mail->isSMTP();                     // Set mailer to use SMTP
		$mail->Host = 'smtp.gmail.com';		//'baratheon.aserv.co.za; mail.crustforex.co.za';  // Specify main and backup SMTP servers
		$mail->SMTPAuth = true;               // Enable SMTP authentication
		$mail->Username = 'luckmolf@gmail.com';   // SMTP username
		$mail->Password = 'LuckyMo@85';            // SMTP password
		$mail->SMTPSecure = 'tls'; //'tls';        // Enable TLS encryption, `ssl` also accepted
		$mail->Port = 587; //465; //587;			// TCP port to connect to

		$to = 'gopolangpascaline@gmail.com';
		$from = 'luckmolf@gmail.com';
		$message = nl2br($message);

		$message = $name.", ".$message;

		$mail->From      = $from; //From address
		$mail->AddAddress ( $to );	  //email to send to
		$mail->addReplyTo( $email ); //address to show replyTo
		$mail->isHTML(true);
		$mail->FromName  = 'Web Notification'; //default name it can be changed
		$mail->Subject   = $subject;  //mail subject
		$mail->Body      = $message;  //message body
		
		if($mail->Send()) { //now send the email
			echo "OK: email message was sent!"; //if email was sent show message
		} else {
			echo "Sorry Failed to send message!"; //if email fail sending throw message
		}		
	}
	else {
		echo "Missing required information!";
	}
}

?>