<?php
session_start();

require_once('config/connect.php');
require_once('model/lecture_model.php');
require_once('model/student_model.php');
require_once('model/module_model.php');
require_once('model/exam_model.php');
require_once('model/reports_model.php');

?>